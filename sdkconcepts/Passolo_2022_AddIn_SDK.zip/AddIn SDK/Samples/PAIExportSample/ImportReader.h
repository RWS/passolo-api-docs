#pragma once
#include "../../addin.h"

//--------------------------------------------------------------------------------
/// <summary>
/// A class to import files that have been written from this add-in
/// </summary>
//--------------------------------------------------------------------------------
class CImportReader
{
public:
    CImportReader(LPCWSTR filename, IPAIImport *callback);
    ~CImportReader();
    BOOL Import();

protected:
    CString m_strFileName;
    IPAIImport *m_pCallback;

    CString m_strCurrentText;
    DWORD m_nCurrentListID;
    LONG m_nCurrentNumber;
    LONG m_nCurrentExtNumber;

    void ResetCurrentText();
    void AppendLineToCurrentText(LPCTSTR line);
    BOOL HandleIDLine(LPCTSTR line);
    void HandleCurrentText();
};

