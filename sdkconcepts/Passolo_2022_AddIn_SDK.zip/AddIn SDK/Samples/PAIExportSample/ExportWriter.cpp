#include "StdAfx.h"
#include "ExportWriter.h"


//********************************************************************************
/// <summary>
/// 
/// </summary>
/// <returns></returns>
//********************************************************************************
CExportWriter::CExportWriter(void)
{
}


//********************************************************************************
/// <summary>
/// 
/// </summary>
/// <returns></returns>
//********************************************************************************
CExportWriter::~CExportWriter(void)
{
}

//********************************************************************************
/// <summary>
/// Called to open the output file
/// </summary>
/// <param name="filename"></param>
/// <returns></returns>
//********************************************************************************
HRESULT CExportWriter::EWOpen(LPCWSTR filename)
{
    if (!m_File.Open(filename, CFile::modeCreate | CFile::modeWrite))
        return S_FALSE;

    return S_OK;
}

//********************************************************************************
/// <summary>
/// Called for each string list that is exported
/// </summary>
/// <param name="filename"></param>
/// <param name="stringlist"></param>
/// <param name="expopt"></param>
/// <returns></returns>
//********************************************************************************
HRESULT CExportWriter::EWWrite(LPCWSTR filename, IPAIStringList *stringlist, IPAIExportOptions *expopt)
{
    if (m_File.m_pStream == NULL)
        return S_FALSE;

    PAISTRUCT_LISTINFO listinfo;
    stringlist->SLGetListInfo(&listinfo);

    int count = 0;
    stringlist->SLGetTokenCount(&count);

    for (int i = 0; i < count; i++)
    {
        BOOL bInFilter = FALSE;
        expopt->EOTokenInFilter(i, &bInFilter);
        if (!bInFilter)
            continue;

        IPAIToken *token = NULL;
        stringlist->SLGetToken(i, &token);

        if (token == NULL)
            continue;

        CString line;

        // Write string list id and string number 
        COleVariant vaNumber;
        token->TGetProperty(TPROP_NUMBER, &vaNumber);

        COleVariant vaExtNumber;
        token->TGetProperty(TPROP_EXTNUMBER, &vaExtNumber);

        line.Format(_T("@%lu-%d-%d---------------\n"),
            listinfo.ID,
            vaNumber.lVal,
            vaExtNumber.lVal);
        m_File.WriteString(line);

        // Write the text
        COleVariant vaText;
        token->TGetProperty(TPROP_TEXT, &vaText);
        m_File.WriteString(vaText.bstrVal);
        m_File.WriteString(_T("\n"));
    }

    return S_OK;
}

//********************************************************************************
/// <summary>
/// 
/// </summary>
/// <param name="filename"></param>
/// <returns></returns>
/// <created>UPh,30.03.2011</created>
/// <changed>UPh,30.03.2011</changed>
//********************************************************************************
HRESULT CExportWriter::EWClose(LPCWSTR filename)
{
    m_File.Close();
    return S_OK;
}

//********************************************************************************
/// <summary>
/// 
/// </summary>
/// <returns></returns>
/// <created>UPh,30.03.2011</created>
/// <changed>UPh,30.03.2011</changed>
//********************************************************************************
HRESULT CExportWriter::EWDestroy()
{
    delete this;
    return S_OK;
}
