﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Pass.AddIn.Core;
using System.IO;

namespace DnExportSample
{
    //--------------------------------------------------------------------------------
    /// <summary>
    /// A class to import files that have been written from this add-in
    /// </summary>
    //--------------------------------------------------------------------------------
    class ImportReader
    {
        private string _FileName;
        private CPAIImport _Callback;

        private string _CurrentText = "";
        private int _CurrentListID = 0;
        private int _CurrentNumber = 0;
        private int _CurrentExtNumber = 0;

        //********************************************************************************
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="filename">The file to import</param>
        /// <param name="callback">Callback functions to Passolo</param>
        /// <returns></returns>
        //********************************************************************************
        public ImportReader(string filename, CPAIImport callback)
        {
            _FileName = filename;
            _Callback = callback;
        }


        //********************************************************************************
        /// <summary>
        /// Starts the import
        /// </summary>
        /// <returns></returns>
        //********************************************************************************
        public bool Import()
        {
            using (StreamReader file = new StreamReader(_FileName))
            {
                while (!file.EndOfStream)
                {
                    string line = file.ReadLine();

                    if (line.Length > 0 && line[0] == '@')
                    {
                        // Send current text to Passolo
                        HandleCurrentText();

                        // Handle the new id 
                        HandleIDLine(line);
                        continue;
                    }

                    // Append line to current string
                    AppendLineToCurrentText(line);
                }
            }

            HandleCurrentText();

            return true;
        }

    //********************************************************************************
    /// <summary>
    /// Resets the current text and the current string number
    /// </summary>
    /// <returns></returns>
    //********************************************************************************
        void ResetCurrentText()
        {
            _CurrentNumber = 0;
            _CurrentExtNumber = 0;
            _CurrentText = "";

        }

        //********************************************************************************
        /// <summary>
        /// Appends a line to the current text
        /// </summary>
        /// <param name="line"></param>
        /// <returns></returns>
        //********************************************************************************
        void AppendLineToCurrentText(string line)
        {
            if (_CurrentText != "")
                _CurrentText += "\n";
            _CurrentText += line;
        }

        //********************************************************************************
        /// <summary>
        /// Reads the line of format "@[ListID]-[StringNumber]-[StringExtNumber]"
        /// </summary>
        /// <param name="line"></param>
        /// <returns></returns>
        //********************************************************************************
        bool HandleIDLine(string line)
        {
            if (line.Length < 3 || line[0] != '@')
                return false;

            string [] fields = line.Split('@', '-');
            if (fields.Length < 4)
                return false;

            int listid;
            if (!int.TryParse(fields[1], out listid))
                return false;
        

            if (_CurrentListID != listid)
            {
                // Switch to another string list
                _CurrentListID = listid;
                _Callback.DefineID(_CurrentListID);
            }

            ResetCurrentText();

            // Read string number
            int number;
            if (!int.TryParse(fields[2], out number))
                return false;

            // Read extended string number
            int extnumber;
            if (!int.TryParse(fields[3], out extnumber))
                return false;


            _CurrentNumber = number;
            _CurrentExtNumber = extnumber;

            return true;
        }

        //********************************************************************************
        /// <summary>
        /// Sends the current text to Passolo 
        /// </summary>
        /// <returns></returns>
        //********************************************************************************
        void HandleCurrentText()
        {
            if (_CurrentListID == 0 ||
                _CurrentNumber == 0 ||
                _CurrentText == "")
                return;


            _Callback.Translate(_CurrentNumber, _CurrentExtNumber, 0, _CurrentText);

            ResetCurrentText();
        }

    }
}
