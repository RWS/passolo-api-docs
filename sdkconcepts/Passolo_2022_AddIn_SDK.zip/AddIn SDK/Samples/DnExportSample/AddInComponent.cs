﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Pass.AddIn.Framework;
using Pass.AddIn.Core;

namespace DnExportSample
{
    class AddInComponent : AddIn
    {
        //********************************************************************************
        /// <summary>
        /// 
        /// </summary>
        /// <param name="init"></param>
        /// <param name="apptools"></param>
        /// <param name="addin"></param>
        /// <returns></returns>
        /// <created>UPh,30.03.2011</created>
        /// <changed>UPh,30.03.2011</changed>
        //********************************************************************************
        public override int Initialize(CPAIInit init, CPAIApplicationTools apptools, CPAIAddIn addin)
        {
            init.Ident = "ExportExample.Net";
            init.InfoText = "Example for an export add-in.";
            init.Name = "Export Example"; // localizable text
            init.Type = AddinType.Export | AddinType.Import;

            return 0;
        }

    }
}
