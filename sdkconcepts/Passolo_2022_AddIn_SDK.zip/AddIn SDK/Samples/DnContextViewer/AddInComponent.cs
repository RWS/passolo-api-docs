﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Pass.AddIn.Core;
using Pass.AddIn.Framework;

namespace DnContextViewer
{
    //--------------------------------------------------------------------------------
    /// <summary>
    /// The standard component for all Passolo add-ins
    /// </summary>
    //--------------------------------------------------------------------------------
    public class AddInComponent : AddIn
    {
        ///<summary>global access to Passolo application tools</summary>
        static public CPAIApplicationTools StaticApplicationTools { get; set; }

        //********************************************************************************
        /// <summary>
        /// Defines basic add-in parameteres
        /// </summary>
        /// <param name="init">Write parameteres to this object</param>
        /// <param name="apptools">Callback function to Passolo application</param>
        /// <param name="addin">An object with callbacks concerning this add-in</param>
        /// <returns></returns>
        /// <created>UPh,27.06.2011</created>
        /// <changed>UPh,27.06.2011</changed>
        //********************************************************************************
        public override int Initialize(CPAIInit init, CPAIApplicationTools apptools, CPAIAddIn addin)
        {
            StaticApplicationTools = apptools;
            init.Ident = "Context Viewer";
            init.Name = Properties.Resources.strAddInName; // Properties.Resources.ContextViewerName;
            init.InfoText = Properties.Resources.strAddInInfo; // Properties.Resources.ContextViewerDesc;
            init.Type = AddinType.Tools;
            return 0;
        }

        
    }
}
