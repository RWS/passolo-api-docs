﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Pass.AddIn.Core;
using Pass.AddIn.Framework;

namespace DnContextViewer
{
    //--------------------------------------------------------------------------------
    /// <summary>
    /// Component for defining a resource display
    /// </summary>
    //--------------------------------------------------------------------------------
    class ResourceDisplayComponent : ResourceDisplays
    {
        //********************************************************************************
        /// <summary>
        /// Returns the definition of our resource display
        /// </summary>
        /// <param name="resource"></param>
        /// <param name="displays"></param>
        /// <returns></returns>
        //********************************************************************************
        public override uint GetResourceDisplays(CPAIResource resource, ref List<CPAIResourceDisplay> displays)
        {
            CPAIResourceDisplay disp = new CPAIResourceDisplay();

            disp.Name = "Context Viewer";
            disp.ID   = 1;
            disp.Type = ResourceDisplayType.CustomEditor;
            disp.Flags = ResourceDisplayFlags.SourceList | 
                         ResourceDisplayFlags.TranslationList;

            displays.Add(disp);

            return 0;
        }

        //********************************************************************************
        /// <summary>
        /// not used
        /// </summary>
        /// <param name="resoure"></param>
        /// <param name="displayId"></param>
        /// <returns></returns>
        //********************************************************************************
        public override IPAINetStandardResourceInfo GetStandardResourceInfo(CPAIResource resoure, int displayId)
        {
            return null;
        }
    }
}
