﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Pass.AddIn.Framework;
using Pass.AddIn.Core;

namespace DnContextViewer
{
    //--------------------------------------------------------------------------------
    /// <summary>
    /// Component for showing a custom editor
    /// </summary>
    //--------------------------------------------------------------------------------
    class CustomGuiComponent : CustomGUI 
    {
        //********************************************************************************
        /// <summary>
        /// Called by Passolo to return an IPAINetCustomEditor implementation
        /// </summary>
        /// <param name="editor"></param>
        /// <param name="resource"></param>
        /// <returns></returns>
        //********************************************************************************
        public override IPAINetCustomEditor CreateCustomEditor(CPAIResourceEditor editor, CPAIResource resource)
        {
            return new HtmlView(editor);
        }
    }
}
