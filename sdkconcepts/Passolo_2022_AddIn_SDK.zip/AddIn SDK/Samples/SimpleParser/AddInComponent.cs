﻿using System;
using System.Collections.Generic;
using System.Text;
using Pass.AddIn.Core;
using Pass.AddIn.Framework;
using DnSimpleParser.Properties;

namespace DnSimpleParser
{
    public class AddInComponent : AddIn
    {
        //********************************************************************************
        /// <summary>
        /// Initializes the addin
        /// </summary>
        /// <param name="init">contains properties to be set</param>
        /// <param name="apptools">To access the Passolo application object, can be stored for later usage</param>
        /// <param name="addin">To access this addin object, can be stored for later usage</param>
        /// <returns></returns>
        //********************************************************************************
        public override int Initialize(CPAIInit init, CPAIApplicationTools apptools, CPAIAddIn addin)
        {
            // Set the identifier and names
            init.Ident = "TBFParser";  // Identifies this add-in

            // The type of this add-in
            init.Type = AddinType.CustomParser;

            // User-friendly name and info 
            init.Name     = Resources.strAddInName; 
            init.InfoText = Resources.strAddInInfo;

            return 0;
        }
    }
}
