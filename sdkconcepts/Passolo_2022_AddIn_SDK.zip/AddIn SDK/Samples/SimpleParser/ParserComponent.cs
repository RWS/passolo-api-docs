﻿using System;
using System.Collections.Generic;
using System.Text;
using Pass.AddIn.Core;
using Pass.AddIn.Framework;
using System.IO;

namespace DnSimpleParser
{
    public class ParserComponent : Pass.AddIn.Framework.Parser
    {
        //********************************************************************************
        /// <summary>
        /// 
        /// </summary>
        /// <param name="parserData"></param>
        /// <returns></returns>
        /// <created>FSa,22.04.2009</created>
        /// <changed>FSa,22.04.2009</changed>
        //********************************************************************************
        public override int GetCustomParserData(ref CPAICustomParserData parserData)
        {
            parserData.FileExt = TBFFileParser.FileTypeExtension;
            parserData.FileDesc = TBFFileParser.FileTypeDescription;
            parserData.Flags = (int) CustomParserFlags.SourceOptions;

            return 0;
        }


        //********************************************************************************
        /// <summary>
        /// Called by Passolo for all file parsing operations (Update Source List, Generate Target, ...)
        /// </summary>
        /// <param name="filename">The file that is parsed</param>
        /// <param name="action">Current operation</param>
        /// <param name="customFile">Supplies the parameters for the operation</param>
        /// <returns></returns>
        //********************************************************************************
        public override long ParseFile(string filename, enmParsingTypes action, CPAICustomFile customFile)
        {
            TBFFileParser parser = new TBFFileParser(filename, action, customFile);

            switch (action)
            {
                case enmParsingTypes.CheckFile:
                {
                    // We only check the file extension
                    string ext = Path.GetExtension(filename);
                    if (string.Compare(ext, "." + TBFFileParser.FileTypeExtension, true) == 0)
                        return (long) enmParseCheck.CheckOK;
                    else
                        return -1;
                }

                case enmParsingTypes.ListContent:
                case enmParsingTypes.ScanSource:
                case enmParsingTypes.ScanTarget:
                case enmParsingTypes.GenerateTarget:
                {
                    if (!parser.ParseFile())
                        return -1;
              
                    break;
                }
            }
    
            return 0;
        }

        public override int QueryTargetPath(string par, string projectpath, string srcpath, int langid, ref string result)
        {
            return -1;
        }

        public override int EditCustomFileOptions(CPAIFileOptions[] fileOptions, int select)
        {
            return 0;
        }

    }
}
