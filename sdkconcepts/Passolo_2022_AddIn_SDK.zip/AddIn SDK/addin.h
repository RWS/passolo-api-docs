// addin.h
// Definitions and interfaces for PASSOLO add-ins.
// This header file is included from the add-ins.

#ifndef __ADDIN_H__
#define __ADDIN_H__

#pragma pack(push, 8)

// Common interface version
#define PAI_VERSION 112

// Interface Versions by Type
#define PAI_VERSION_EXPORT          110
#define PAI_VERSION_IMPORT          110                   
#define PAI_VERSION_CUSTOMRSC       110
#define PAI_VERSION_CUSTOMPARSER    110
#define PAI_VERSION_TRANSLATE       110
#define PAI_VERSION_SPELLCHECK      110
#define PAI_VERSION_SEGMENTER       110
#define PAI_VERSION_TOOLS           110
#define PAI_VERSION_ADDINCOLLECTION 110

// For compatibility
//#define IPAITokenList IPAIResource
//#define TLSetStringProperty RscSetStringProperty
//#define TLSetIntProperty RscSetIntProperty
//#define TLSetBinaryProperty RscSetBinaryProperty
//#define TLGetProperty RscGetProperty
//#define TLGetListInfo RscGetListInfo
//#define TLHandleToken RscHandleToken
//#define TLLog         RscLog
//#define TLGetToken    RscGetToken
//#define TLGetProject  RscGetProject

struct IPAIToken;
struct IPAIResource;
struct IPAIProject;
struct IPAIStringList;
struct PAISTRUCT_GLOSSARY;
struct IPAIResData;

//////////////////////////////////////////////////////////////////////////////
// Definitions 
// 
//////////////////////////////////////////////////////////////////////////////

// Values for the type of an add-in
enum PAIType
{
    PAITYPE_EXPORT          = 0x0001,  // Can export texts
    PAITYPE_IMPORT          = 0x0002,  // Can import texts
    PAITYPE_CUSTOMRSC       = 0x0004,  // Can handle custom resources
    PAITYPE_CUSTOMPARSER    = 0x0008,  // Can parse files
    PAITYPE_TRANSLATE       = 0x0010,  // Can look for fuzzy translations or terminology
    PAITYPE_SPELLCHECK      = 0x0020,  // Spellchecking
    PAITYPE_SEGMENTER       = 0x0040,  // Segmenting 
    PAITYPE_TOOLS           = 0x0080,  // Implements one or more tool functions
    PAITYPE_ADDINCOLLECTION = 0x0100,  // AddIn that manages a list of other add-ins
    PAITYPE_INTERNAL        = 0x8000,  // internal usage
};

// Types for IPAIApplicationTools::ATGetLangCode
enum PAILangCodeType
{
    LCTYPE_WIN          =  0, // 3-letter-code from windows
    LCTYPE_639_2B       =  1, // ISO 639-2 bibl.
    LCTYPE_639_2T       =  2, // ISO 639-2 term.
    LCTYPE_639_1        =  3, // ISO 639-1 (2 letter)
    LCTYPE_ISO          =  4, // ISO 639-1, if available, ISO_639 term otherwise
    LCTYPE_ISO3166_2    =  5, // ISO3166, dreistellig
    LCTYPE_ISO3166_1    =  6, // ISO3166, zweistellig
    LCTYPE_WIN_RGN      =  7, // dreistelliger Windows-Regionalcode
    LCTYPE_LANG_RGN     =  8, // combined <LCTYPE_639_1>-<LCTYPE_ISO3166_1>
    LCTYPE_HEX          =  9, // Hexvalues
    LCTYPE_TEXT         = 10, // Display-Text (localized)
    LCTYPE_UNKNOWN      = 11, // Unknown Type for IPAIApplicationTools::ATGetLangID

    LCTYPE_ENGLISH_TEXT = 12, // Display-Text (English)
    LCTYPE_DECIMAL      = 13, // Decimal LCID value
    
    LCTYPE_SDLX         = 14, // SDLX Code
    LCTYPE_TRADOS       = 15, // Trados Code
    LCTYPE_RFC_4646     = 16, // Like LCTYPE_LANG_RGN but e.g. with "zh-HANT" for "zh-CHT"
};


// Values for the style of an add-in
enum  PAIStyle
{
    PAISTYLE_SETUPDATA       = 0x0001,  // Uses setup data and has a setup dialog
    PAISTYLE_NODIRECTCHECK   = 0x0004,  // Don't call check routines with direct checking
};

// Values for type of log functions
enum PAILogType
{
    PAILOG_INFO    = 0x0001, 
    PAILOG_ERROR   = 0x0002,  
    PAILOG_SUCCESS = 0x0003,   
    PAILOG_WARNING = 0x0004,
    PAILOG_STATUS  = 0x0008,

    // Additional Bits to combine with the type
    PAILOG_BOLD      = 0x00100000,  // The text is shown in bold
    PAILOG_ITALIC    = 0x00200000,  // The text is shown in italic-type
    PAILOG_UNDERLINE = 0x00400000,  // The text is underlined
};

// Values for PAISTRUCT_TOKENINFO::Flags
enum PAITokenFlags
{
    TIF_MNEMONIC   = 0x0001,   // Token uses ampersand for mnemonic
    TIF_TRANSLATED = 0x0002,   // Text is already translated
    TIF_READONLY   = 0x0004,   // String is read-only
    TIF_HIDDEN     = 0x0008,   // String is hidden
};

// Normalized resource type, Values for PAISTRUCT_TOKENINFO::ResType and RSCPROP_NORMTYPE
enum PAIResType
{
    TIRT_USER      =  0,  // Unknown resource type
    TIRT_MENU      =  4,  // A Menu
    TIRT_DIALOG    =  5,  // A Dialog
    TIRT_STRING    =  6,  // A Stringlist
    TIRT_ABBR      =  9,  // An Accelerator Table
    TIRT_VER       = 16,  // A Version info
};     

// Values for PAISTRUCT_TOKENINFO::CtrlType
enum PAICtrlType
{
    TICT_USER            =  0,
    TICT_BUTTON          = 0x0080,
    TICT_EDIT            = 0x0081,
    TICT_STATIC          = 0x0082,
    TICT_LISTBOX         = 0x0083,
    TICT_SCROLLBAR       = 0x0084,
    TICT_COMBOBOX        = 0x0085,
    TICT_CC_HEADER       = 0x8001,
    TICT_CC_LISTVIEW     = 0x8002,
    TICT_CC_TREEVIEW     = 0x8003,
    TICT_CC_COMBOBOXEX   = 0x8004,
    TICT_CC_TABCONTROL   = 0x8005,
    TICT_CC_TOOLTIPS     = 0x8006,
    TICT_CC_TRACKBAR     = 0x8007,
    TICT_CC_UPDOWN       = 0x8008,
    TICT_CC_PROGRESS     = 0x8009,
    TICT_CC_HOTKEY       = 0x800A,
    TICT_CC_ANIMATE      = 0x800B,
    TICT_CC_MONTHCAL     = 0x800C,
    TICT_CC_DATETIMEPICK = 0x800D,
};

// Values for parameter 'what' of IPAIStringList::SLGetTokenText()
enum PAITokenTextType
{
    GTT_Source,        // Get source text
    GTT_Trans,         // Get translation text
    GTT_Comment,       // Get project comment
    GTT_TransComment,  // Translator comment
	GTT_ParserComment,

      // Additional Flags
    GTT_UseEscSeq = 0x0100, // Strings will be converted to use EscapeSequences for control characters
};

// Values for PAISTRUCT_EXPIMPDATA::MultiFileMode
enum PAIMultiFileMode
{
    MFM_SEPARATE             = 0, // Can only write one string list to an export file
    MFM_CAN_COLLECT          = 1, // Supports collecting multiple string lists into a single export file
    MFM_CAN_COLLECT_LANGUAGE = 3, // Supports collecting multiple string lists of the same target language
    MFM_COLLECT              = 4, // Always collects multiple string lists into a single export file
    MFM_COLLECT_LANGUAGE     = 5, // Always collects multiple string lists to language files
    
    // OBSOLETE values, please use the corresponding new values
    MFM_SINGLE               = 0, // use MFM_SEPARATE
    MFM_ALLOWMULTI           = 1, // use MFM_CAN_COLLECT
    MFM_MULTI                = 2, // not supported anymore
};

// Values for PAISTRUCT_EXPIMPDATA::Flags
enum PAIExpImpFlags
{
    EIF_SRC_LISTS = 0x0001, // Can export/import source lists
    EIF_TRN_LISTS = 0x0002, // Can export/import translation lists

    // For ExportTarget-AddIns, when exporting translation bundles
    EIF_LICENSED_BUNDLE_ONLY = 0x0004, // allows only licensed bundles
    EIF_NO_LICENSED_BUNDLE   = 0x0008, // don't allow licensed bundles
    EIF_EXPORTMARK_ONLY      = 0x0010, // allways use "mark as exported"
    EIF_NO_EXPORTMARK        = 0x0020, // never use "mark as exported"
    EIF_NO_SPLIT             = 0x0040, // don't allow splitted bundles
};

// Values for parameters of IPAICustomControls::CCGetCtrlRect
enum PAICtrlRectIndexType
{
    // inx
    GCI_DIALOG  = -1,  // Index for dialog
};

enum PAICtrlRectQueryType
{
    // type
    GCR_CALC    = 0,   // Returns the calculated rectangle of the Control 
    GCR_MINSIZE = 1,   // Returns the minimum size of the control 
    GCR_OPTSIZE = 2,   // returns the optimal size of the control 
    GCR_CHECKSIZE = 3, // not used
};

enum PAICtrlRectFlags
{
    // flags
    GCF_CLIENT = 0x0001, // Returns client rect, if inx == GCI_DIALOG
    GCF_PIXELS = 0x0002, // Returns rect in pixels relative to the parent window of the dialog
                         // if not set, return DLUs relative to the client rect of the dialog
};

// Flags for Controls, used by IPAICustomControls::CCGetEditFlags
enum PAICtrlEditFlags
{
    CF_DIALOG        = 0x0001, // This item is the dialog
    CF_NODISPLAY     = 0x0100, // The control will not be displayed
    CF_NOMOVE        = 0x0200, // The control is not moveable
    CF_NOSIZELEFT    = 0x1000, // The control cannot be sized to the left
    CF_NOSIZETOP     = 0x2000, // The control cannot be sized to the right
    CF_NOSIZERIGHT   = 0x4000, // The control cannot be sized at the top
    CF_NOSIZEBOTTOM  = 0x8000, // The control cannot be sized at the bottom
    CF_NOSIZE        = 0xF000, // The control cannot be sized
    CF_NOLAYOUT      = (CF_NOSIZE | CF_NOMOVE),
    CF_NOBOUND       = 0x00010000 // The control is no bound for resizing the dialog
};

// Flags for IPAICustomControls::CCUpdateCtrl and IPAICustomEditor::CEUpdateCtrl
enum PAIUpdateCtrlFlags
{
    UCF_TEXT          = 0x0001, // Control text needs to be updated
    UCF_POSITION      = 0x0002, // Control position needs to be updated
    UCF_STYLE         = 0x0004, // Control style has changed
    UCF_PROPERTY      = 0x0008, // Custom property of control has changed
    UCF_ALL           = 0x000F,
};

enum PAIParsingTypes
{
    PARSE_CHECK_FILE      = 0, // Checks if the source file can be parsed by this add-in
    PARSE_LIST_CONTENT    = 1, // Lists content of file
    PARSE_SCAN_SOURCE     = 2, // Scans source file
    PARSE_GENERATE_TARGET = 3, // Generates target file
    PARSE_SCAN_TARGET     = 4, // Scans target file for alignment 
    PARSE_GET_SOURCE_TIME = 5, // Virtual source files: Request for time of source
};

// Flags for PAISTRUCT_CCINFO and PAISTRUCT_CEINFO
enum PAICustomControlFlags
{
    CIF_WANT_MOUSECLICKS    = 0x0001,  // CCOnWindowMessage is called on WM_LBUTTONDOWN, WM_LBUTTONUP, WM_LBUTTONDBLCLK
    CIF_WANT_MOUSEMESSAGES  = 0x0002,  // CCOnWindowMessage is called on all mouse messages
    CIF_WANT_COMMANDS       = 0x0004,  // CCOnWindowMessage is called on layout commands
    CIF_WANT_SELCHANGE      = 0x0008,  // CCOnSelChange is called when selection has changed
    CIF_WANT_TEXTINPUT      = 0x0010,  // CCOnTextInput is called when the user is editing text
    CIF_WANT_FILTERTOKEN    = 0x0020,  // CCOnFilterToken is called when the string list is filled
    CIF_WANT_ARROWKEYS      = 0x0040,  // WM_KEYDOWN, WM_KEYUP with arrow keys
    CIF_WANT_ALLKEYS        = 0x0080,  // WM_KEYDOWN, WM_KEYUP
    CIF_WANT_ACTIVATE       = 0x0100,  // CCOnWindowMessage(WM_ACTIVATE) is called when the language tab is selected
    CIF_KEYBOARD_HOOK       = 0x1000,  // WM_KEYDOWN is sent by installing a keyboard hook
    //CIF_WANT_ALL           = 0x01FF,
};

// Values for PAISTRUCT_CEINFO::PAISTRUCT_CEINFO
enum PAICustomEditorSizeMode
{
    CSM_FIXED           = 0, // Size is fixed, CEGetSize is called once
    CSM_DYNAMIC         = 1, // Size changes, CEGetSize is called on change of window size and when changing data
    CSM_MAXCLIENT       = 2, // Size is always same as client of resource editor
    CSM_VIRTWND         = 0x0100, // PASSOLO does not create a window with the full size
    CSM_VIRTWND_FIXED   = (CSM_FIXED | CSM_VIRTWND),   // Size is fixed, CEGetSize is called once
    CSM_VIRTWND_DYNAMIC = (CSM_DYNAMIC | CSM_VIRTWND), // Size is fixed, CEGetSize is called once
};


// Commands for Custom Controls (wpar in CCOnWindowMessage(WM_COMMAND, wpar, 0, BOOL *bCancel))
enum PAICustomControlCommands
{
    CCC_LAY_ALIGN_LEFT           = 40000,
    CCC_LAY_ALIGN_RIGHT          = 40001,
    CCC_LAY_ALIGN_TOP            = 40002,
    CCC_LAY_ALIGN_BOTTOM         = 40003,
    CCC_LAY_ALIGN_HORIZ          = 40004,
    CCC_LAY_EVEN_ACROSS          = 40006,
    CCC_LAY_EVEN_DOWN            = 40007,
    CCC_LAY_SAME_WIDTH           = 40008,
    CCC_LAY_SAME_HEIGHT          = 40009,
    CCC_LAY_SAME_BOTH            = 40010,
    CCC_LAY_ALIGN_VERT           = 40011,
    CCC_LAY_SIZETOCONTENT        = 40012,
    CCC_LAY_FLIP                 = 40013,
    CCC_LAY_CENTER_DLGHORZ       = 40015,
    CCC_LAY_CENTER_DLGVERT       = 40016,
    CCC_LAY_RESETDLG             = 40017,
    CCC_LAY_RESETCTL             = 40018,
    CCC_LAY_FONT                 = 40019,
};


// Values for parameter select of TGetProperty
enum PAIPropSelType
{
     PROPSEL_DEFAULT      = 0, // returns property depending of current settings
     PROPSEL_SRC          = 1, // returns source property
     PROPSEL_TRN          = 2, // returns translation property
     PROPSEL_EDIT         = 3, // returns source property for source strings and translation property for translation strings
     PROPSEL_TRN_ORIGINAL = 4, // Type of IPAITokenSelection: Translation strings, but original (source) view
};


// PASSOLO defined resource types
#ifndef RT_PSL_STRINGTABLE
#define RT_PSL_STRINGTABLE MAKEINTRESOURCEW(230)
#define RT_PSL_ICONFILE    MAKEINTRESOURCEW(231)
#define RT_PSL_CURSORFILE  MAKEINTRESOURCEW(232)
#define RT_PSL_BITMAPFILE  MAKEINTRESOURCEW(233)
#define RT_PSL_IMAGEFILE   MAKEINTRESOURCEW(234)
#endif


// Editions
#define EDITION_NONE          0  // No License found
#define EDITION_DEMO          1  // Demo version
#define EDITION_TRANSLATOR    2  // Translatior edition 
#define EDITION_ESSENTIAL     3  // Passolo Essential
#define EDITION_UNIVERSITY    4  // Like professional with additional disclaimer
#define EDITION_PROFESSIONAL  5  // Professional edtion
#define EDITION_TEAM          6  // Team Edition
#define EDITION_COLLABORATION 7  // Collaboration Edition

// Load Values 
#define LOAD_MANUAL     0 
#define LOAD_ON_STARTUP 1
#define LOAD_ON_USE     2  // Default

//////////////////////////////////////////////////////////////////////////////
// Structures
// 
//////////////////////////////////////////////////////////////////////////////

//--------------------------------------------------------------------------------
/// <summary>
/// 
/// </summary>
//--------------------------------------------------------------------------------
struct PAISTRUCT_INTERFACE_VERSION
{
    // Use PAI_SET_INTERFACE_VERSION to set MainVersion and Type[]
    DWORD  Main;     
    DWORD  Type[12]; 
};

//----------------------------------------------------------------------------
// struct PAISTRUCT_INIT
// Base-Structure for add-in information
//----------------------------------------------------------------------------
struct PAISTRUCT_INIT
{
    // Set by PASSOLO
    LANGID Lang;            // Current language of user interface
    BOOL   IsRegistration;  // TRUE = This Call to PAIFN_Initialize is for add-in registration only

    // Set by add-in
    DWORD  Type;            // Defines the type of the add-in, combination of PAITYPE_...
    DWORD  Style;           // Defines properties of the addin, combination of PAISTYLE_...
    WCHAR  Name[80];        // Name  of the Add-In
    WCHAR  InfoText[256];   // Additional infos on the export format
    WCHAR  Ident[80];       // An unlocalized Name to identify the AddIn
    WCHAR  ReferFile[256];  // Refers to another file that has to be loaded (PAIFN_Intialize returns PAIERR_REFER)
    DWORD  FirstLoadType;   // LOAD_MANUAL, LOAD_ON_STARTUP or LOAD_ON_USE (default)
    DWORD  Events;          // Which events shall raised in the add-in PAIEVENT_...
};

// Use this macro in PAIFN_Initialize to set all version values
#define PAI_SETVERSION(init)                        \
init->MainVersion = PAI_VERSION;                    \
init->TypeVersion[0]  = PAI_VERSION_EXPORT;         \
init->TypeVersion[1]  = PAI_VERSION_IMPORT;         \
init->TypeVersion[2]  = PAI_VERSION_CUSTOMRSC;      \
init->TypeVersion[3]  = PAI_VERSION_CUSTOMPARSER;   \
init->TypeVersion[4]  = PAI_VERSION_TRANSLATE;      \
init->TypeVersion[5]  = PAI_VERSION_SPELLCHECK;     \
init->TypeVersion[6]  = PAI_VERSION_SEGMENTER;      \
init->TypeVersion[7]  = PAI_VERSION_TOOLS;          \
init->TypeVersion[8]  = PAI_VERSION_ADDINCOLLECTION \
init->TypeVersion[9]  = 0;                          \
init->TypeVersion[10] = 0;                          \
init->TypeVersion[11] = 0;                          \


#define PAI_SET_INTERFACE_VERSION(ver)       \
ver->Main = PAI_VERSION;                     \
ver->Type[0]  = PAI_VERSION_EXPORT;          \
ver->Type[1]  = PAI_VERSION_IMPORT;          \
ver->Type[2]  = PAI_VERSION_CUSTOMRSC;       \
ver->Type[3]  = PAI_VERSION_CUSTOMPARSER;    \
ver->Type[4]  = PAI_VERSION_TRANSLATE;       \
ver->Type[5]  = PAI_VERSION_SPELLCHECK;      \
ver->Type[6]  = PAI_VERSION_SEGMENTER;       \
ver->Type[7]  = PAI_VERSION_TOOLS;           \
ver->Type[8]  = PAI_VERSION_ADDINCOLLECTION; \
ver->Type[9]  = 0;                           \
ver->Type[10] = 0;                           \
ver->Type[11] = 0;                        



//----------------------------------------------------------------------------
// struct PAIRSTUCT_EXPIMPDATA
// Additional add-in information for export and import
//----------------------------------------------------------------------------
struct PAISTRUCT_EXPIMPDATA
{
    WCHAR  Ext[16];       // Default extension of exported files
    WORD   MultiFileMode; // MFM_... Ability to handle multiple files
    WORD   Flags;         // EIF_... Flags 
    int    TagFormat;     // Which tag format is needed? (0 = no tag transformation needed)
};

//----------------------------------------------------------------------------
// struct PAISTRUCT_LISTINFO
// Used by IPAIExport::GetListInfo
//----------------------------------------------------------------------------
struct PAISTRUCT_LISTINFO
{
    DWORD  ID;           // List-ID
    LANGID Lang1;        // Source-Language
    LANGID Lang2;        // Target-Language
    UINT   CodePage1;    // Source-CodePage
    UINT   CodePage2;    // Target-CodePage
    WCHAR  LangCode1[8]; // 3-letter code of source-language
    WCHAR  LangCode2[8]; // 3-letter code of target-language
};

//----------------------------------------------------------------------------
// struct PAISTRUCT_TOKENINFO
// Used by IPAIExort::GetTokenInfo
//----------------------------------------------------------------------------
struct PAISTRUCT_TOKENINFO
{
    LONG    Number;    // Numbers of token, ...
    LONG    ExtNumber; // ...used to identify token in import
    BOOL    InFilter; //OBSOLETE // TRUE, if the token is contained in the export filter 
    WORD    ResType;   // TIRT_...  Type of resource
    WORD    CtrlType;  // TICT_...  Type of control if ResType == TIRT_DIALOG
    WCHAR   Info[120]; // Description of the token (e.g. "Button 332 in dialog 12");
    DWORD   Flags;     // TIF_..
};

// Flags for PAISTRUCT_CUSTOMPARSERDATA
enum PAICustomParserFlags
{
    CPF_SOURCE_OPTIONS          = 0x0001, // has setup for source file options
    CPF_MULTI_SOURCE_OPTIONS    = 0x0002, // allows editing multiple source file options
    CPF_WIN32_SOURCE_OPTIONS    = 0x0004, // uses PASSOLO source file options

    CPF_TARGET_OPTIONS          = 0x0010, // has setup for source file options
    CPF_MULTI_TARGET_OPTIONS    = 0x0020, // allows editing multiple source file options
    CPF_WIN32_TARGET_OPTIONS    = 0x0040, // uses PASSOLO source file options

    CPF_VIRTUAL_SOURCE          = 0x0100, // Does not work on an existing source file
};

//----------------------------------------------------------------------------
// struct PAISTRUCT_CUSTOMPARSERDATA
// Additional add-in information for custom parsers
//----------------------------------------------------------------------------
struct PAISTRUCT_CUSTOMPARSERDATA
{
    WCHAR FileExt[256];   // Extension of handled files, separate multiple extensions with ";", e.g. "frm;bas"
    WCHAR FileDesc[256];  // Description of files types
    DWORD Flags;          // CPF_...
};

//----------------------------------------------------------------------------
// struct PAISTRUCT_CCINFO
// 
//----------------------------------------------------------------------------
struct PAISTRUCT_CCINFO
{
    WCHAR DLUName[8];  // Name of dialog units
    int   MinStepX;    // Minimum step in X-Direction (DLUs)
    int   MinStepY;    // Minimum step in Y-Direction (DLUs)
    DWORD Flags;       // CIF_...
};

//----------------------------------------------------------------------------
// struct PAISTRUCT_CEINFO
// 
//----------------------------------------------------------------------------
struct PAISTRUCT_CEINFO
{
    int   SizeMode;    // CSM_..
    DWORD Flags;       // CIF_...
};



//----------------------------------------------------------------------------
// struct PAISTRUCT_SPELLCHECKDATA
// Additional add-in information for spell checking (depending on a language)
//----------------------------------------------------------------------------
struct PAISTRUCT_SPELLCHECKDATA
{
    int    Mode;         // [OUT] SPELLCHECK_QUERY and/or SPELLCHECK_DIALOG
};

// Types for Tools (see PAIFN_GetToolInfo)
enum PAIToolTypes
{
    // When to show?
    TT_ALL                  = 0,      // (Default), use tool independently of the current selection
    TT_PROJECT              = 0x00000001, // use in project window
    TT_SRCRES               = 0x00000010, // use for source resources
    TT_SRCSTRING            = 0x00000020, // use for source strings
    TT_TRNRES               = 0x00000100, // use for translation resource
    TT_TRNSTRING            = 0x00000200, // use for translation strings
                        
    // Where to show?   
    TT_MENU                 = 0x00001000, // show in main menu
    TT_STRINGLIST           = 0x00002000, // show in string list popup menu
    TT_RESOURCEEDITOR       = 0x00004000, // show in resource editor
    TT_IMPORTMENU           = 0x10000000, // show in import menu

    // Special Tools
    TT_OPTIMIZELAYOUT       = 0x00008000, // This is an auto-layout tool, implements PAIFN_ToolOptimizeLayout
    TT_EXTPROJECT           = 0x00010000, // This tool allows opening external projects 
    TT_RESOURCEDISPLAY      = 0x00020000, // This tools allows displaying dialog or resource editors
    TT_TAGGING              = 0x00040000, // This tools converts tag formats, implements PAIFN_TagString and PAIFN_UntagString
    TT_EXPORTTARGET         = 0x00080000, // This tools manages exported files, implements PAIFN_ToolGetExportHandlerData, PAIFN_ToolHandleExport
};

enum PAITagModes
{
    TM_NoTags       = 0, // Token does not contain tags
    TM_HasTags      = 1, // Use tags, but allow user to reset to untagged
    TM_AlwaysTags   = 2, // Always use tags
};

enum PAITagReasons
{
    TR_Unknown       = 0,
    TR_Edit          = 1,
    TR_Segmenting    = 2,
    TR_Checking      = 3,
    TR_SpellingCheck = 4,
    TR_Simulation    = 5,
    TR_Statistics    = 6,
    TR_TransformTag  = 7, 
	TR_InlinePattern = 8,
	TR_EditEditor	 = 9,
};

//--------------------------------------------------------------------------------
/// <summary>
/// 
/// </summary>
//--------------------------------------------------------------------------------
enum PAIExpSettingsReasons
{
    XR_Unknown = 0,
    XR_Profile = 1, // For writing to option profiles
    XR_Embed   = 2, // For embedding into translation bundles
};

//--------------------------------------------------------------------------------
/// <summary>
/// 
/// </summary>
//--------------------------------------------------------------------------------
enum PAITagFormat
{
    TF_NONE             = 0,   // no tags, use native parser format
    TF_DEFAULT          = 1,   // use default format for export, import or translation add-in
    TF_PASSOLO_INTERNAL = 2,   // internal PASSOLO format for tags (PTX)
    TF_STRIPTAGS        = 3,   // all tags are stripped from the string
	TF_EDIT				= 4,   // escape text outside tags, then convert tags to target text
    TF_TMX              = 100,
    TF_RTF              = 101,
    TF_TTX              = 102,
    TF_TRADOSSTUDIO     = 103,
    // Additional format numbers can be arranged between export or tranlation addin and the tagging addin 
    // (use a number > 1000)
};


//----------------------------------------------------------------------------
// struct PAISTRUCT_TOOLINFO
// Define a single tool command
//----------------------------------------------------------------------------
struct PAISTRUCT_TOOLINFO
{
    WCHAR MenuName[80];  // Name in tools menu
    WCHAR InfoText[256]; // Additional info text in status bar
    DWORD Type;          // TT_ defines type of tool
    DWORD Flags;         // TF_... (no flags defined yet)
};

// Flags for PAISTRUCT_OPTIMIZELAYOUT
enum PAIOptimizeLayoutFlags
{
    OLF_STARTFROMSOURCE = 0x0001,  // start from source positions instead of current target positions
    OLF_ALLOWSMALLER    = 0x0002,  // allow reduction in control width, if text fits
};


//----------------------------------------------------------------------------
// struct PAISTRUCT_OPTIMIZELAYOUT
// 
//----------------------------------------------------------------------------
struct PAISTRUCT_OPTIMIZELAYOUT
{
    DWORD Flags;
};

//----------------------------------------------------------------------------
// struct PAISTRUCT_EXTPROJECT
// Information for an external project
//----------------------------------------------------------------------------
struct PAISTRUCT_EXTPROJECT
{
    WCHAR ID[256];       // Identifies Project
    WCHAR InfoText[256]; // Text displayed to the user
    WCHAR UserID[50];    // "" or ID of an user who is already listed in the project
    BOOL IsBundle;       // This is a translation bundle
    BOOL SupportsListCheckOut;   // This project needs check in/check out handling on list base
    BOOL SupportsStringCheckOut; // This project needs check in/check out handling on string base (not implemented yet)
};

//--------------------------------------------------------------------------------
/// <summary>
// Used for ATNotifyOpenExtFiles 
/// </summary>
//--------------------------------------------------------------------------------
struct PAISTRUCT_NOTIFY_OPEN_EXT_FILES
{
    BOOL ReadOnly;       // File cannot be modified
    BOOL CheckedOut;     // File is checked out 
    WCHAR Message[256];  // If ReadOnly: Reason for being read-only
}; 

//--------------------------------------------------------------------------------
/// <summary>
// Used for ATNotifyStoreExtFiles 
/// </summary>
//--------------------------------------------------------------------------------
struct PAISTRUCT_NOTIFY_STORE_EXT_FILES
{
    WCHAR Message[256];  // TODO
}; 


//--------------------------------------------------------------------------------
/// <summary>
/// 
/// </summary>
//--------------------------------------------------------------------------------
struct PAISTRUCT_TAGGING
{
    int _buf; // No parameters defined yet
};

//--------------------------------------------------------------------------------
/// <summary>
/// Features for ExportHandler
/// </summary>
//--------------------------------------------------------------------------------
struct PAISTRUCT_EXPORTTARGET_DATA
{
    WCHAR  TargetName[80];   // User-friendly name of target for bundles
    WCHAR  TargetInfo[1000]; // Info text, can be HTML or use Passolo links ("[[...�]]");
    WORD   MultiFileMode;    // MFM_... Ability to handle multiple files
    WORD   Flags;            // EIF_... Flags 
};

//--------------------------------------------------------------------------------
/// <summary>
/// 
/// </summary>
//--------------------------------------------------------------------------------
struct PAISTRUCT_EXPORTTARGET_FILE
{   
    int    Mode;           // SYNCBUNDLE_... Current mode/direction of sync
    TCHAR  Path[MAX_PATH]; // Path of File
    LANGID Language;       // Language, if only one target language is in the bundle

    DWORD  ExportID;     
    TCHAR  SplitID[20];
    
    // Written by AddIn (or by Passolo when creating update bundle)
    WCHAR  ExportInfo[1000]; // Info text, e.g. used server, mail address, ...
    DWORD  StringListIDs[500]; // one (for multiple files) or more ids (when single file is used) ended with 0
};

//--------------------------------------------------------------------------------
/// <summary>
/// Contains data for add-in in the collection
/// </summary>
//--------------------------------------------------------------------------------
struct PAISTRUCT_ADDININFO
{
    int   ID;             
    WCHAR Path[300];    // A path or some other descriptor
    FILETIME TimeStamp; // TimeStamp of the AddIn, can be 0 if Path contains an existing file
};



// Standard types for resource display
enum PAIResourceDisplayStandard
{
    RDS_TEXT                = 0x00010000,
    RDS_HTML                = 0x00020000,
    RDS_HEX                 = 0x00040000
};


// Flags for PAISTRUCT_RESOURCEDISPLAY
enum PAIResourceDisplayFlags
{
    RDF_SOURCE_LIST             = 0x0001, // Display is for Source List
    RDF_TRANSLATION_LIST        = 0x0002, // Display is for Translation List
    RDF_USE_SOURCE_DATA         = 0x0004, // Display uses source data in translation list
    RDF_IMPLEMENT_STANDARD_TEXT = (0x0008 | RDS_TEXT), // Implements the display of standard text
    RDF_IMPLEMENT_STANDARD_HTML = (0x0008 | RDS_HTML), // Implements the display of HTML 
    RDF_IMPLEMENT_STANDARD_HEX  = (0x0008 | RDS_HEX),  // Implements the display of Hex values
};

// Types fo rPAISTRUCT_RESOURCEDISPLAY
enum PAIResourceDisplayType
{
    RDT_DEFAULT             = 0,    // Type is defined by RSCPROP_CUSTOM_CONTROLS or RSCPROP_CUSTOM_EDITOR
    RDT_CUSTOM_CONTROLS     = 1,    // AddIn creates Controls for dialog editor
    RDT_CUSTOM_EDITOR       = 2,    // AddIn has own editor for the resource
    RDT_USE_STANDARD_TEXT   = (3 | RDS_TEXT),  // Resource is a text format that can be shown with a
                                               // resource display addin that implements standard text
    RDT_USE_STANDARD_HTML   = (3 | RDS_HTML),  // Same for HTML
    RDT_USE_STANDARD_HEX    = (3 | RDS_HEX),   // Same for hex values
};


//----------------------------------------------------------------------------
// struct PAISTRUCT_RESOURCEDISPLAY
// 
//----------------------------------------------------------------------------
struct PAISTRUCT_RESOURCEDISPLAY
{
    WCHAR Name[32];  // The name of this display (e.g. "Original", "Translation");
    WCHAR Ident[32]; // Unlocalized name for this resource display (normally the English Name)
    DWORD ID;        // A ID to distinguish between different displays
    int   Type;      // Type (RDT_DEFAULT, ...)
    DWORD Flags;     // Flags (RDF_SOURCE_LIST, ...)
};

//--------------------------------------------------------------------------------
/// <summary>
/// If a add-in uses a standard resource display, it must provide an interface
/// to the data and information
/// </summary>
//--------------------------------------------------------------------------------
struct IPAIStandardResourceInfo
{
    virtual HRESULT SRIGetType(int *type) = 0;
    virtual HRESULT SRIGetData(TCHAR filepath[256], BOOL *bTemporary) = 0;
    
    // For RDS_TEXT
    virtual HRESULT SRIGetTokenTextPosition(IPAIToken *token, int *line, int *col, int *len) = 0;
    //virtual HRESULT SRIFindTokenAtPosition(int line, int col, IPAIToken **token) = 0;  (wird wahrscheinlich nicht ben�tigt)
    
    virtual HRESULT SRIDestroy() = 0;
};

//--------------------------------------------------------------------------------
/// <summary>
/// Additional add-in information for translation
/// </summary>
//--------------------------------------------------------------------------------
struct PAISTRUCT_TRANSLATEDATA
{
    int   TagFormatTranslate;     // Which tag format is needed for translation? (0 = no tag transformation needed)
    int   TagFormatConcordance;   // ...for concordance
    int   TagFormatTerminology;   // ...for terminology
    
    int   Type;                   // TRANS_AUTOTRANS, TRANS_FUZZYMATCH, TRANS_CONCORDANCE and TRANS_TERMINOLOGY
};

//////////////////////////////////////////////////////////////////////////////
// Callback - Interfaces to PASSOLO Application
// 
//////////////////////////////////////////////////////////////////////////////

//----------------------------------------------------------------------------
// struct IPAIRegularExpression
// 
//----------------------------------------------------------------------------
struct IPAIRegularExpression
{
    virtual HRESULT RXInit(LPCWSTR pattern, DWORD flags) = 0;
    virtual HRESULT RXFindMatch(LPCWSTR str, int pos = 0, int len = -1) = 0;
    virtual HRESULT RXGetMatch(LPINT matchpos, LPINT matchlen) = 0;
    virtual HRESULT RXGetBackref(int inx, BSTR *str) = 0;
    virtual HRESULT RXDelete() = 0;
};



//----------------------------------------------------------------------------
// struct IPAICustomProperties
// Access to custom properties 
//----------------------------------------------------------------------------
struct IPAICustomProperties
{
    virtual HRESULT CPSetStringProperty(LPCWSTR name, LPCWSTR value) = 0;
    virtual HRESULT CPSetIntProperty(LPCWSTR name, int value) = 0;
    virtual HRESULT CPSetBinaryProperty(LPCWSTR name, LPBYTE value, int size) = 0;
    virtual HRESULT CPGetProperty(LPCWSTR name, VARIANT *value) = 0;
    virtual HRESULT CPEnumProperties(int inx, VARIANT *name, VARIANT *value = NULL) = 0;
    virtual HRESULT CPHasProperty(LPCWSTR name) = 0;
    virtual HRESULT CPRemoveProperty(LPCWSTR name) = 0;
    virtual HRESULT CPRemoveAll() = 0;
};

//----------------------------------------------------------------------------
// struct IPAIFileOptions
// 
//----------------------------------------------------------------------------
struct IPAIFileOptions
{
    virtual HRESULT FOSetStringProperty(LPCWSTR name, LPCWSTR value) = 0;
    virtual HRESULT FOSetIntProperty(LPCWSTR name, int value) = 0;
    virtual HRESULT FOSetBinaryProperty(LPCWSTR name, LPBYTE value, int size) = 0;
    virtual HRESULT FOGetProperty(LPCWSTR name, VARIANT *value) = 0;
    virtual HRESULT FOGetCustomProperties(IPAICustomProperties **props) = 0;
    virtual HRESULT FOGetProject(IPAIProject **project) = 0;
    virtual HRESULT FOGetSourceFileOptions(IPAIFileOptions **srcoptions) = 0; // used when editing target file options
};


//----------------------------------------------------------------------------
// struct IPAIAddIn
// Access to add-in data
//----------------------------------------------------------------------------
struct IPAIAddIn
{
    //virtual HRESULT AIOpenDataKey(HKEY *datakey) = 0;
    //virtual HRESULT AICloseDataKey() = 0;
    virtual HRESULT AISetStringProperty(LPCWSTR name, LPCWSTR value) = 0;
    virtual HRESULT AISetIntProperty(LPCWSTR name, int value) = 0;
    virtual HRESULT AISetBinaryProperty(LPCWSTR name, LPBYTE value, int size) = 0;
    virtual HRESULT AIGetProperty(LPCWSTR name, VARIANT *value) = 0;
    virtual HRESULT AIGetCustomProperties(IPAICustomProperties **props) = 0;
    virtual HRESULT AIGetDataFolder(LPWSTR path, int npath) = 0;
};

//----------------------------------------------------------------------------
// interface IPAIExport OBSOLETE (use IPAIStringList and IPAIExportOptions
// 
//----------------------------------------------------------------------------
struct IPAIExport
{
    virtual HRESULT ExpGetListInfo(/*[out]*/ PAISTRUCT_LISTINFO *listinfo) = 0;
    virtual HRESULT ExpGetTokenCount(/*[out]*/ int *count) = 0;
    virtual HRESULT ExpGetToken(int index, /*[out]*/ IPAIToken **token) = 0;
    virtual HRESULT ExpGetTokenInfo(/*[in]*/ int index, /*[out]*/ PAISTRUCT_TOKENINFO *tokeninfo) = 0;
    virtual HRESULT ExpGetTokenText(/*[in]*/int index, /*[in]*/int what, /*[out]*/ BSTR *text) = 0;
    virtual HRESULT ExpGetResourceCount(/*[out]*/int *count) = 0;
    virtual HRESULT ExpGetResource(int index, /*[out]*/ IPAIResource **resource) = 0;
    virtual HRESULT ExpLog(/*[in]*/ int type, /*[in]*/ LPCWSTR text) = 0;
    virtual HRESULT ExpGetFileOptions(/*[out]*/ IPAIFileOptions **options) = 0;
};

//----------------------------------------------------------------------------
// struct IPAIExportOptions
// 
//----------------------------------------------------------------------------
struct IPAIExportOptions
{
    virtual HRESULT EOTokenInFilter(int index, LPBOOL bInFilter) = 0;
    virtual HRESULT EOLog(/*[in]*/ int type, /*[in]*/ LPCWSTR text) = 0;
    virtual HRESULT EOGetTokenText(int index, BSTR *src, BSTR *trn, UINT flags = 0, int tagformat = TF_DEFAULT) = 0;
    virtual HRESULT EOTransformTags(LPCTSTR strFrom, int tagformatFrom, BSTR *strTo, int tagformatTo) = 0;
};

//----------------------------------------------------------------------------
// struct IPAIExportWriter
// 
//----------------------------------------------------------------------------
struct IPAIExportWriter
{
    virtual HRESULT EWOpen(LPCWSTR filename) = 0; // called once for each output file                    
    virtual HRESULT EWWrite(LPCWSTR filename, IPAIStringList *stringlist, IPAIExportOptions *expopt) = 0; // called for each string list
    virtual HRESULT EWClose(LPCWSTR filename) = 0;
    virtual HRESULT EWDestroy() = 0;
};


//----------------------------------------------------------------------------
// interface IPAIImport
// 
//----------------------------------------------------------------------------
struct IPAIImport
{
    virtual HRESULT ImpGetListInfo(/*[out]*/ PAISTRUCT_LISTINFO *listinfo) = 0; // will not set ID
    virtual HRESULT ImpDefineID(/*[in]*/DWORD id) = 0;  // List-ID, must be defined before the first call to Translate()
    virtual HRESULT ImpLog(/*[in]*/int type, LPCWSTR text) = 0;

    // Simple Translation
    virtual HRESULT ImpTranslate(/*[in]*/LONG number, /*[in]*/LONG extnumber, /*[in]*/int flags, /*[in]*/BSTR text, int tagformat = TF_DEFAULT) = 0;

    // Advanced Translation
    virtual HRESULT ImpGetTokenCount(/*[out]*/ int *count) = 0;
    virtual HRESULT ImpGetToken(int index, /*[out]*/ IPAIToken **token) = 0;
    virtual HRESULT ImpFindToken(LONG number, LONG extnumber, IPAIToken **token) = 0;
    virtual HRESULT ImpGetResourceCount(/*[out]*/int *count) = 0;
    virtual HRESULT ImpGetResource(int index, /*[out]*/ IPAIResource **resource) = 0;
    virtual HRESULT ImpFindResource(LONG number, /*[out]*/ IPAIResource **resource) = 0;
    virtual HRESULT ImpIncrementCounter() = 0;
    virtual HRESULT ImpGetFileOptions(/*[out]*/ IPAIFileOptions **options) = 0;
};

//----------------------------------------------------------------------------
// struct IPAIExtProject
// 
//----------------------------------------------------------------------------
struct IPAIExtProject
{
    virtual HRESULT ExtConnect(IPAIProject *project) = 0;
    virtual HRESULT ExtGetInfo(PAISTRUCT_EXTPROJECT *data) = 0;
    virtual HRESULT ExtOpenFiles(LPCWSTR fileid, BOOL checkout, LPCWSTR targetfolder, /*[in]*/long cookie) = 0;
    virtual HRESULT ExtClose() = 0;
    virtual HRESULT ExtStoreFiles(LPCWSTR fileid, BOOL checkin, LPCWSTR folder, long cookie) = 0;
    virtual HRESULT ExtCheckInFile(LPCWSTR fileid) = 0;
};


// Property Names for IPAIApplicationTools
#define ATPROP_EMPTYRSC_DLL        MAKEINTRESOURCEW(-1)      // returns path of emptyrsc dll
#define ATPROP_PSL_VERSION         MAKEINTRESOURCEW(-2)      // returns PASSOLO version, e.g. 350 for PASSOLO 3.5.06.123
#define ATPROP_PSL_SERVICEPACK     MAKEINTRESOURCEW(-9)      // returns PASSOLO service pack number, e.g. 6 for PASSOLO 3.5.06.123
#define ATPROP_PSL_BUILD           MAKEINTRESOURCEW(-3)      // returns PASSOLO build number, e.g. 6 for PASSOLO 3.5.06.123
#define ATPROP_USER_NAME           MAKEINTRESOURCEW(-4)      // return current user's name
#define ATPROP_USER_FULLNAME       MAKEINTRESOURCEW(-5)      // return current user's full name
#define ATPROP_USER_COMMENT        MAKEINTRESOURCEW(-6)      // return current user's comment
#define ATPROP_EDITION             MAKEINTRESOURCEW(-7)      // returns the current PASSOLO edition (EDITION_...)
#define ATPROP_STANDARD_PROJECT_FOLDER MAKEINTRESOURCEW(-8)  // returns the standard folder where Projects are saved
#define ATPROP_FEATURE_DOTNET      MAKEINTRESOURCE(-20)
#define ATPROP_FEATURE_DELPHI      MAKEINTRESOURCE(-21)
#define ATPROP_FEATURE_JAVA        MAKEINTRESOURCE(-22)
#define ATPROP_FEATURE_DATABASE    MAKEINTRESOURCE(-23)
#define ATPROP_FEATURE_BUNDLESYNC  MAKEINTRESOURCE(-24)
#define ATPROP_FEATURE_GROUPSHARE  MAKEINTRESOURCE(-25)
#define ATPROP_FEATURE_CLOUD       MAKEINTRESOURCE(-26)
#define ATPROP_ADDIN_FOLDER_0      MAKEINTRESOURCE(-30)
#define ATPROP_ADDIN_FOLDER_1      MAKEINTRESOURCE(-31)

#define ATPROP_PROXY_TYPE          MAKEINTRESOURCE(-53) // 0 = automatic, 1 = none, 2 = use address/username/password
#define ATPROP_PROXY_ADDRESS       MAKEINTRESOURCE(-50) // The address of the proxy, if used ("<address>:<port>")
#define ATPROP_PROXY_USERNAME      MAKEINTRESOURCE(-51) // The name of the user, if needed
#define ATPROP_PROXY_PASSWORD      MAKEINTRESOURCE(-52) // The password, if needed

#define ATPROP_AUTOTRANS_ENABLED  MAKEINTRESOURCE(-54)

// Property names for IPAIAddIn
#define AIPROP_PATH                MAKEINTRESOURCE(-1)   // Full path of add-in file
#define AIPROP_FOLDER              MAKEINTRESOURCE(-2)   // Full path of add-in folder 

// Internal Property Names for IPAIToken
#define TPROP_NUMBER               MAKEINTRESOURCEW(-1)
#define TPROP_EXTNUMBER            MAKEINTRESOURCEW(-46)
#define TPROP_TEXT                 MAKEINTRESOURCEW(-2)
#define TPROP_OLDTEXT              MAKEINTRESOURCEW(-3)
#define TPROP_ID                   MAKEINTRESOURCEW(-5)
#define TPROP_EXTID                MAKEINTRESOURCEW(-6)
#define TPROP_CLASS                MAKEINTRESOURCEW(-7)
#define TPROP_STYLE                MAKEINTRESOURCEW(-8)
#define TPROP_EXSTYLE              MAKEINTRESOURCEW(-9)
#define TPROP_CTL_X                MAKEINTRESOURCEW(-10)
#define TPROP_CTL_Y                MAKEINTRESOURCEW(-11)
#define TPROP_CTL_CX               MAKEINTRESOURCEW(-12)
#define TPROP_CTL_CY               MAKEINTRESOURCEW(-13)
#define TPROP_STATE_NEW            MAKEINTRESOURCEW(-14)
#define TPROP_STATE_READONLY       MAKEINTRESOURCEW(-15)
#define TPROP_STATE_CHANGED        MAKEINTRESOURCEW(-16)
#define TPROP_STATE_HIDDEN         MAKEINTRESOURCEW(-17)
#define TPROP_STATE_CORRECTION     MAKEINTRESOURCEW(-18)
#define TPROP_STATE_COORDCHANGED   MAKEINTRESOURCEW(-19)
#define TPROP_STATE_REVIEW         MAKEINTRESOURCEW(-20)
#define TPROP_STATE_PRETRANSLATED  MAKEINTRESOURCEW(-52)
#define TPROP_STATE_TRANSLATED     MAKEINTRESOURCEW(-21)
#define TPROP_STATE_BOOKMARK       MAKEINTRESOURCEW(-22)
#define TPROP_STATE_LOCKED         MAKEINTRESOURCEW(-41)
#define TPROP_STATE_DELETED        MAKEINTRESOURCEW(-43)
#define TPROP_CTL_PARENT           MAKEINTRESOURCEW(-23)
#define TPROP_FONT                 MAKEINTRESOURCEW(-24)
#define TPROP_CTL_TOGGLE_ALIGNMENT MAKEINTRESOURCEW(-25)  // Flag: Toggle all alignment settings
#define TPROP_CTL_MIRROR           MAKEINTRESOURCEW(-26)  // Flag: Mirror the control (with childs)
#define TPROP_CTL_MIRROR_THIS      MAKEINTRESOURCEW(-27)  // Flag: Mirror the control (w/o childs)
#define TPROP_INDEX                MAKEINTRESOURCEW(-28)  // Index of token in its resource
#define TPROP_CTL_CUSTOMDIALOG     MAKEINTRESOURCEW(-29)  // This token defines the dialog frame
#define TPROP_CTL_CUSTOMFONT       MAKEINTRESOURCEW(-30)  // This token contains a standard font property (TPROP_FONT)
#define TPROP_VARIABLE_ID          MAKEINTRESOURCEW(-31)  // The ID is variable, it may change in the next update
#define TPROP_COMMENT              MAKEINTRESOURCEW(-32)  // this is used (incorrectly) in parsers (instead of TPROP_PARSER_COMMENT) and MUST be treated as TPROP_PARSER_COMMENT
#define TPROP_MAXLENGTH            MAKEINTRESOURCEW(-33)  // Max. Length for translation text
#define TPROP_MAXLINES             MAKEINTRESOURCEW(-53)  // Max. number of lines in translation text
#define TPROP_DO_SEGMENT           MAKEINTRESOURCEW(-34)  // Text should be segmented
#define TPROP_SEGMENT_NUMBER       MAKEINTRESOURCEW(-35)  // Number of segment
#define TPROP_IS_FONT_TOKEN        MAKEINTRESOURCEW(-36)  // This token contains the font for the dialog
#define TPROP_TAGMODE              MAKEINTRESOURCEW(-37)  // TM_NoTags, TM_HasTags or TM_AlwaysTags
#define TPROP_CTL_GROUP            MAKEINTRESOURCEW(-38)  // Define a group for the control when parsing
#define TPROP_CTL_OPTIMAL_CX       MAKEINTRESOURCEW(-39)
#define TPROP_CTL_OPTIMAL_CY       MAKEINTRESOURCEW(-40)
#define TPROP_MATCH_RATE           MAKEINTRESOURCEW(-42)
#define TPROP_STATE_INVISIBLE      MAKEINTRESOURCEW(-44)
#define TPROP_STATECOLOR           MAKEINTRESOURCEW(-45)
#define TPROP_TM_ID                MAKEINTRESOURCEW(-47)
#define TPROP_TEXT_NOTAG           MAKEINTRESOURCEW(-48)  // Returns text without tags
#define TPROP_TEXT_EDITTAG         MAKEINTRESOURCEW(-49)  // Returns text with PTX tags (Passolo internal)
#define TPROP_TRANS_COMMENT        MAKEINTRESOURCEW(-50)  // In The translation comment
#define TPROP_STATE_MULTILINE      MAKEINTRESOURCEW(-51)  // The Multiline Flag 
#define TPROP_PARSER_COMMENT       MAKEINTRESOURCEW(-54)  
#define TPROP_PROJECT_COMMENT      MAKEINTRESOURCEW(-55)
#define TPROP_ORIGIN		       MAKEINTRESOURCEW(-56)
#define TPROP_TEXT_INLINE_PATTERN  MAKEINTRESOURCEW(-57)  // Returns text with tags and inline pattern tags (Passolo internal)
#define TPROP_ALIGN_ONLY_TEXT	   MAKEINTRESOURCEW(-58)
#define TPROP_ORIGIN_TYPE	       MAKEINTRESOURCEW(-59)
#define TPROP_ID_COMPUTED          MAKEINTRESOURCEW(-60)

// Internal Property Names for IPAIResource
#define RSCPROP_TOKENCOUNT          MAKEINTRESOURCEW(-1)
#define RSCPROP_RESTYPE             MAKEINTRESOURCEW(-2)
#define RSCPROP_RESNAME             MAKEINTRESOURCEW(-3)
#define RSCPROP_NORMTYPE            MAKEINTRESOURCEW(-4)   // The normalized resource type TIRT_...
#define RSCPROP_FIRSTTOKENINDEX     MAKEINTRESOURCEW(-5)
#define RSCPROP_CUSTOM_CONTROLS     MAKEINTRESOURCEW(-20)  // AddIn creates Controls for dialog editor
#define RSCPROP_CUSTOM_EDITOR       MAKEINTRESOURCEW(-21)  // AddIn has own editor for the resource
#define RSCPROP_USE_AMPERSAND       MAKEINTRESOURCEW(-22)  // The resource uses ampersands to define an access key
#define RSCPROP_USE_UNDERSCORE      MAKEINTRESOURCEW(-23)  // The resource uses underscores to define an access key
#define RSCPROP_LINKED_FONT         MAKEINTRESOURCEW(-24)  // Returns the string list font, if linked to dialog fonts
#define RSCPROP_BINARY_DATA         MAKEINTRESOURCEW(-25)  // For binary resources: Returns binary data
#define RSCPROP_STATE_TRANSLATED    MAKEINTRESOURCEW(-26)  // For binary resources: Data has been changed by translator
#define RSCPROP_STATE_READONLY      MAKEINTRESOURCEW(-27)  // Resource is read-only
#define RSCPROP_STATE_HIDDEN        MAKEINTRESOURCEW(-28)  // Resource is not visible in translation list
#define RSCPROP_STATE_DELETED       MAKEINTRESOURCEW(-43)  // Resource is deleted (i.e. in recycle bin)
#define RSCPROP_DO_SEGMENT          MAKEINTRESOURCEW(-34)  // All texts in this resource should be segmented
#define RSCPROP_FILE_PARSER         MAKEINTRESOURCEW(-44)
#define RSCPROP_RESOURCE_PARSER     MAKEINTRESOURCEW(-45)
#define RSCPROP_NAME_IS_PATH        MAKEINTRESOURCEW(-46) // 1 = The name contains \'s (or /'s) to be sorted to a folder structur
#define RSCPROP_ICON                MAKEINTRESOURCEW(-47) // Number (< 0 = predefined, > 0 from DLL or by PAIFN_GetIconHandle) or name of icon file
#define RSCPROP_NUMBER              MAKEINTRESOURCEW(-48) // CTokres.m_nNumber

// Properties for IPAICustomFile and IPAIFileOptions
#define CFPROP_ACTION                     MAKEINTRESOURCEW(-1)    // long, Current Action
#define CFPROP_SOURCEFILE                 MAKEINTRESOURCEW(-2)    // BSTR, Path of source file
#define CFPROP_TARGETFILE                 MAKEINTRESOURCEW(-3)    // BSTR, Path of target file
#define CFPROP_EXTLANGCOUNT               MAKEINTRESOURCEW(-4)    // long, Number of languages to extract
#define CFPROP_SOURCELANGUAGE             MAKEINTRESOURCEW(-5)    // long, ID of source language
#define CFPROP_TARGETLANGUAGE             MAKEINTRESOURCEW(-6)    // long, ID of target language
#define CFPROP_SOURCECODEPAGE             MAKEINTRESOURCEW(-7)    // long, Codepage of source language
#define CFPROP_TARGETCODEPAGE             MAKEINTRESOURCEW(-8)    // long, Codepage of target language
#define CFPROP_SOURCETITLE                MAKEINTRESOURCEW(-9)    // BSTR, Title of source
#define CFPROP_SOURCEOPT_MFC              MAKEINTRESOURCEW(-10)   // long flag, Source file created with MFC
#define CFPROP_SOURCEOPT_PASSLIB          MAKEINTRESOURCEW(-11)   // long flag, Source file created with Passlib
#define CFPROP_SOURCEOPT_EXTRACT_BITMAPS  MAKEINTRESOURCEW(-12)   // long flag, Extract bitmaps
#define CFPROP_SOURCEOPT_EXTRACT_ICONS    MAKEINTRESOURCEW(-13)   // long flag, Extract icons and cursors
#define CFPROP_SOURCEOPT_EXTRACT_BINARIES MAKEINTRESOURCEW(-14)   // long flag, Extract other binaries
#define CFPROP_SOURCEOPT_FIRST            MAKEINTRESOURCEW(-19)
#define CFPROP_SOURCEOPT_LAST             MAKEINTRESOURCEW(-10)
#define CFPROP_TARGETOPT_KEEP_RSC         MAKEINTRESOURCEW(-20)   // long flag, Keep Original resources
#define CFPROP_TARGETOPT_ORIGINAL_LANG    MAKEINTRESOURCEW(-21)   // long flag, Mark resources with original language id
#define CFPROP_TARGETOPT_RSC_DLL          MAKEINTRESOURCEW(-22)   // long flag, Generate resource only DLL
#define CFPROP_TARGETOPT_TAG_VERSION      MAKEINTRESOURCEW(-23)   // long flag, Tag version info with language id
#define CFPROP_TARGETOPT_WRITE_LRM        MAKEINTRESOURCEW(-24)   // long flag, Tag version info with language id
#define CFPROP_TARGETOPT_KEEP_NEUTRAL     MAKEINTRESOURCEW(-25)   // long flag, Keep NEUTRAL resources from source file
#define CFPROP_TARGETOPT_FIRST            MAKEINTRESOURCEW(-29)
#define CFPROP_TARGETOPT_LAST             MAKEINTRESOURCEW(-20)
#define CFPROP_SOURCELANGCODEPAGE         MAKEINTRESOURCEW(-50)   // long, Default codepage of source language
#define CFPROP_PARSER                     MAKEINTRESOURCEW(-51)   // BSTR, Parser definition string
#define CFPROP_TARGET_RTL                 MAKEINTRESOURCEW(-52)
#define CFPROP_CREATE                     MAKEINTRESOURCEW(-53)
#define CFPROP_EXTLANG_0                  MAKEINTRESOURCEW(-1255) // long, ..up to 256 language ids
#define CFPROP_EXTLANG_MAX                MAKEINTRESOURCEW(-1000)

// Types for SLStoreResFile 
#define RESFILE_PROJECT            1  // Resfile is attached to project
#define RESFILE_SOURCELIST         2  // Resfile is attached to source list
#define RESFILE_STRINGLIST         3  // Resfile is attached to string list (source list or translation list)
#define RESFILE_DELETEONUPDATE 0x100  // Flag: this file is deleted automatically, when updating the stringlist

// Special language values for (CFPROP_EXTLANG_0 + x)
#define EXTLANG_ALL                MAKELANGID(0xFF, 0)
#define EXTLANG_ALL_EXCEPT_NEUTRAL MAKELANGID(0xFF, 1)

// Properties for IPAIProject
#define PPROP_FOLDER               MAKEINTRESOURCEW(-1)    // Project-Folder
#define PPROP_NAME                 MAKEINTRESOURCEW(-2)    // Project-Name
#define PPROP_ALLOWSETUP           MAKEINTRESOURCEW(-3)    // Are setup functions (and update, generate) allowed?
#define PPROP_PRJ_EXPORTED         MAKEINTRESOURCEW(-4)    // The whole project is exported, no modifications or translations are possible.
#define PPROP_PRJ_EXPORT_ID        MAKEINTRESOURCEW(-5)    // Returns an ID that is created with PExportProject
#define PPROP_TRANS_COUNT          MAKEINTRESOURCEW(-6)    // Total number of strings to translate (all languages)
#define PPROP_TRANSLATED_COUNT     MAKEINTRESOURCEW(-7)    // Total number of strings that are translated (all languages, include for-review)
#define PPROP_REVIEW_COUNT         MAKEINTRESOURCEW(-8)    // Total number of strings that are for review
#define PPROP_TRANS_RATE           MAKEINTRESOURCEW(-9)    // Rate of translations (0 = nothing, 100 = all)
#define PPROP_RUNTIME_ID           MAKEINTRESOURCEW(-10)   // Returns an ID that identifies the project at runtime


// Values for TCGetOption()
// All strings
#define TCO_NUMTABS           0x01000001  // Different number of tabulators
#define TCO_MNEMONIC1         0x01000002  // Missing access key in translated string
#define TCO_MNEMONIC2         0x01000004  // Translated string has access key, but source string has none
#define TCO_EMPTY1            0x01000008  // Missing translation text
#define TCO_EMPTY2            0x01000010  // Empty source string has non-empty translation
#define TCO_SPACES            0x01000040  // Different number of white spaces at beginning or end of string
#define TCO_TEXTLENGTH        0x01000100  // Text too long
#define TCO_SPELLING          0x01000200  // Spelling error
#define TCO_CODEPAGE          0x01000400  // Character not in target code page
#define TCO_TERMINOLOGY       0x01000800  // Is the terminology o.k?
#define TCO_BLOCKEDWORD       0x01001000  // Are blocked words used?
#define TCO_CONSISTENCY       0x01002000  // Do translations match with auto-translation?
#define TCO_PRINTF_ALL        0x01004000  // Inconsistent pritnf formats (check on all resource types)
#define TCO_FORMATMESSAGE_ALL 0x01008000  // Inconsistent pritnf formats (check on all resource types)
#define TCO_TEXTLENGTH_MB     0x01010000  // Textlength for multi-byte string
// Menus
#define TCO_MENUACC        0x02000001  // (not used)
#define TCO_MENUMNEMONIC   0x02000002  // Duplicate access key in menu 
// Dialogs
#define TCO_CTRLSIZE       0x03000001  // Text does not fit to control size          
#define TCO_CTRLOVERLAP    0x03000002  // Control overlaps other control
#define TCO_CTRLOUTSIDE    0x03000004  // Control is not within the dialog borders
#define TCO_CTRLMNEMONIC   0x03000008  // Duplicate access key
#define TCO_CHECKSRC       0x03000010  // Ignore the control size error if it appears already in the source file
// Accelerators
#define TCO_ACCINVALID     0x04000001  // Invalid accelerator.
#define TCO_ACCDUPLICATE   0x04000002  // Duplicate accelerator.
// String Tables
#define TCO_PRINTF         0x05000001  // Inconsistent printf formats
#define TCO_FORMATMESSAGE  0x05000002  // Inconsistent FormatMessage formats

// Custom checking options provided from PAIFN_GetCustomCheckOption
#define TCO_CUSTOM_0       0x00100000  
#define TCO_CUSTOM_1       0x00100001
#define TCO_CUSTOM_2       0x00100002
#define TCO_CUSTOM_3       0x00100003
#define TCO_CUSTOM_4       0x00100004
#define TCO_CUSTOM_5       0x00100005
#define TCO_CUSTOM_6       0x00100006
#define TCO_CUSTOM_7       0x00100007
#define TCO_CUSTOM_8       0x00100008
#define TCO_CUSTOM_9       0x00100009
#define TCO_CUSTOM_10      0x0010000A
#define TCO_CUSTOM_11      0x0010000B
#define TCO_CUSTOM_12      0x0010000C
#define TCO_CUSTOM_13      0x0010000D
#define TCO_CUSTOM_14      0x0010000E
#define TCO_CUSTOM_15      0x0010000F


// Flags for CFHandleResource 
#define HRF_MERGEWITHEXISTING 0x0001   // Resource will be merged to existing resources with same ID
#define HRF_CHECKLANGUAGE     0x0002   // Resource will only be handled, if the Language has to be extracted

// Values for PAISTRUCT_SPELLCHECKDATA.Mode
#define SPELLCHECK_NONE       0x0000   // Cannot spellcheck the language
#define SPELLCHECK_QUERY      0x0001   // (default) Spellchecker checkes words and returns suggestions without user interaction
#define SPELLCHECK_DIALOG     0x0002   // Spellchecker uses own dialog

// Flags for SCCheckSpelling
#define SCF_CHECKONLY         0x0001   // No suggestions for wrong spelled words needed
#define SCF_NOAUTOCORRECTION  0x0002   // No auto-correction
#define SCF_IGNOREUPPERCASE   0x0010   // Ignore upper-case


// Status for IPAISpellCheckResult
#define SCS_OK                0   // Word/Text is ok
#define SCS_CORRECTED         1   // Word/Text has been corrected
#define SCS_ERROR             2   // Word/Text has error, Suggestions may be available
#define SCS_ABORTED           3   // Spell checking has been aborted


// Types for IPAIPropertyDefinitions
#define PDT_UNDEFINED         0  // undefined
#define PDT_STRING            1  // Property is string, uses edit control
#define PDT_INTEGER           2  // Property is integer, uses edit control
#define PDT_BOOLEAN           3  // Property is integer, uses check box
#define PDT_FONT              4  // Property is a LOGFONT
#define PDT_RGB               5  // Property is a COLORREF
#define PDT_CHOICE            6  // Property is a integer, uses combo box
#define PDT_BITFIELD          7  // Property is a bitfield, uses combo box with check boxes
#define PDT_CUSTOM           99  // Addin provides a callback for editing this value (not supported yet)

// Flags for IPAIPropertyDefinitions and Define[Int|String|Binary] Property
#define PDF_READONLY      0x0001 // This property can not be edited
#define PDF_HIDDEN        0x0002 // This property is not displayed to the user
#define PDF_CONSTANT      0x0004 // This property definition can be buffered, it does not change between different strings
#define PDF_SETUP         0x0008 // This property can be edited in source string lists
#define PDF_NO_UPDATE     0x1000 // Don't propagate from source to tranlation when updating
#define PDF_VOLATILE      0x0010 // For Define[]Property: May change with every update, changes are not reported

// Values for parameter usein in IPAIProject::PDefineUserProperty 
#define PDF_USEIN_DELETE     0
#define PDF_USEIN_PROJECT    0x00001000
#define PDF_USEIN_SRCLIST    0x00002000
#define PDF_USEIN_TRNLIST    0x00004000
#define PDF_USEIN_LANGUAGE   0x00008000
#define PDF_USEIN_RESOURCE   0x00010000
#define PDF_USEIN_SRCSTRING  0x00020000
#define PDF_USEIN_TRNSTRING  0x00040000


// Match Flags for IPAITranslation
#define TMF_EXACT                0
#define TMF_IGNORECASE        0x01
#define TMF_IGNOREAMPERSAND   0x02
#define TMF_IGNORESPACES      0x04
#define TMF_IGNOREPUNCT       0x08

// Flags for RscHandleToken()
#define HTF_GETCURRENTDATA    0x00010000 // for Action = PARSE_SCAN_TARGET: Don't modify token, just get current data

// Flags for IPAIRegularExpression::RXInit
#define RFX_NOCASE        0x0001 // ignore case
//#define RFX_GLOBAL        0x0002 // match everywhere in the string
#define RFX_MULTILINE     0x0004 // ^ and $ can match internal line breaks
#define RFX_SINGLELINE    0x0008 // . can match newline character
#define RFX_RIGHTMOST     0x0010 // start matching at the right of the string
//#define RFX_NOBACKREFS    0x0020 // only meaningful when used with GLOBAL and substitute
//#define RFX_FIRSTBACKREFS 0x0040 // only meaningful when used with GLOBAL
//#define RFX_ALLBACKREFS   0x0080 // only meaningful when used with GLOBAL
#define RFX_NORMALIZE     0x0100 // Preprocess patterns: "\\n" => "\n", etc.
#define RFX_EXTENDED      0x0200 // ignore whitespace in pattern
#define RFX_STORE_BACKREFS 0x00010000 // store backrefs (flag must be set if you want to use RXGetBackref)

// Flags for IPAIToken::TUpdate()
#define UPD_NOUNDO          0x0001 // Don't put the modifications to the Undo-Buffer
#define UPD_UNDOFOLLOW      0x0004 // If multiple tokens will be changed in one step, set this flag
                                   // for the second and the following tokens, to have all modifications
                                   // rejected, if the user calls "Undo"
#define UPD_HISTORY         0x0008 // Put this entry to the History List
#define UPD_ALLOWREPLICATE  0x0020 // Check the text modification for replicates
#define UPD_NOUPDATECTRL    0x0800 // CEUpdateCtrl or CCUpdateCtrl is not called


// Flags for IPAIToken::TDefineReferenceID and TDefineReferenceNumber
#define TREF_SIMPLE          0x0001 // Unspecified connection between two strings
#define TREF_TEXT            0x0002 // Uses text from reference target

// Pre-defined Icons (for RSCPROP_ICON)
enum PAIRscDefaultIcons
{
    RSCICON_DEFAULT       = -3,
    RSCICON_BINARY        = -3,
    RSCICON_CURSOR        = -4,
    RSCICON_BITMAP        = -5,
    RSCICON_ICON          = -6,
    RSCICON_MENU          = -7,
    RSCICON_DIALOG        = -8,
    RSCICON_STRING        = -9,
    RSCICON_ACCELERATOR   = -10,
    RSCICON_VERSION       = -11,
    RSCICON_TOOLBAR       = -12,
    RSCICON_HTML          = -13,
    RSCICON_MESSAGETABLE  = -14,
};


enum PAITranslationTypes
{
    TRANS_DEFAULT        = 0,
    TRANS_AUTOTRANS      = 0x0001, // obsolete use TRANS_PRETRANSLATION
    TRANS_PRETRANSLATION = 0x0001, // 100% translation
    TRANS_FUZZYMATCH     = 0x0002, // Fuzzy Matches
    TRANS_CONCORDANCE    = 0x0004,
    TRANS_TERMINOLOGY    = 0x0008,
    TRANS_BLOCKEDWORD    = 0x0010, // (internal usage: use for blocked word check)
    TRANS_MACHINETRANSLATION = 0x0020, // uses only Machine Translation
    TRANS_STRIP_ACCESS_KEY = 0x00010000 // For fuzzy translation: Strip access key before sending string
};

// Options for TRGetOption
enum PAITranslationOptions
{
    TRANSOPT_THISPROJECT    = 1,
    TRANSOPT_OTHERPROJECTS  = 2,
    TRANSOPT_PRJGLOSSARY    = 3,
    TRANSOPT_COMMONGLOSSARY = 4,
    TRANSOPT_AUTOMATION     = 5,
    TRANSOPT_ADDIN          = 6,
};

// Flags f�r IPAIToken::TGetDescription and IPAIToken::SLGetDescription
enum PAIDescriptionFlags
{
    // for IPAIToken
    PAIDESC_NUMBER     = 0x0001, // Add token number
    PAIDESC_NORSC      = 0x0004, // Don't write resource name
    PAIDESC_TITLE      = 0x0008, // Add title of source list
    PAIDESC_TEXT       = 0x0010, // Add token text
    PAIDESC_TEXTABBR   = 0x0020, // Add a abbreviated token text
    PAIDESC_LINKONLY   = 0x0200, // Create only a link with a "*" as placeholder for text

    // for IPAIToken and IPAIStringList
    PAIDESC_LINK       = 0x0040, // Add a link to jump to the token or open the string list (Supported in PASSOLO 7)
    PAIDESC_HIDDENLINK = 0x0080, // Add a link, thats only visible in popup menu (Supported in PASSOLO 7)

    // for IPAIStringList
    PAIDESC_NOPREFIX   = 0x0100  // Don't prefix with "Source list - " or "Translation list - "
};

//--------------------------------------------------------------------------------
/// <summary>
/// Eventvalues for PAIFN_OnProjectEvent
/// </summary>
//--------------------------------------------------------------------------------
//enum PAIProjectEvents
//{
    //PRJEVENT_OPEN  = 1,
    //PRJEVENT_CLOSE = 2,
//};

//--------------------------------------------------------------------------------
/// <summary>
/// 
/// </summary>
//--------------------------------------------------------------------------------
enum PAIEvents
{
    // Project Events
    PAIEVENT_OPENPROJECT            = 0x0001,
    PAIEVENT_CLOSEPROJECT           = 0x0002,
    PAIEVENT_ENDUPDATESOURCELISTS   = 0x0004,
	PAIEVENT_TARGETSGENERATED       = 0x0008, 
    PAIEVENT_BEGINUPDATESOURCELISTS = 0x0010,

    // Token Events
    PAIEVENT_UPDATE_TOKEN           = 0x0100,
};

//--------------------------------------------------------------------------------
/// <summary>
/// 
/// </summary>
//--------------------------------------------------------------------------------
enum PAIImportFlags
{
    IMPORT_VALIDATE = 0x100,
    IMPORT_MERGE    = 0x200,
    IMPORT_RELEASE  = 0x400,
};

///<summary></summary>
enum PAIEditionStringType
{
    PAIEDITION_NAME         = 0x0001,
    PAIEDITION_SHORTVERSION = 0x0002,
    PAIEDITION_VERSION      = 0x0004,
    PAIEDITION_SERVICEPACK  = 0x0010,
    PAIEDITION_BUILD        = 0x0020,
    PAIEDITION_DEFAULT = (PAIEDITION_NAME | PAIEDITION_VERSION),
};

//----------------------------------------------------------------------------
// struct IPAIProject
// Access to a project
//----------------------------------------------------------------------------
struct IPAIProject
{
    virtual HRESULT PSetStringProperty(LPCWSTR name, LPCWSTR value) = 0;
    virtual HRESULT PSetIntProperty(LPCWSTR name, int value) = 0;
    virtual HRESULT PSetBinaryProperty(LPCWSTR name, LPBYTE value, int size) = 0;
    virtual HRESULT PGetProperty(LPCWSTR name, VARIANT *value) = 0;
    virtual HRESULT PGetCustomProperties(IPAICustomProperties **props) = 0;
    virtual HRESULT PStoreResFile(IPAIAddIn *addin,LPCWSTR name, LPCWSTR path) = 0;
    virtual HRESULT PGetResFile(IPAIAddIn *addin, LPCWSTR name, LPWSTR path, int npath) = 0;
    virtual HRESULT PDeleteResFile(IPAIAddIn *addin, LPCWSTR name) = 0;
    virtual HRESULT PGetRuntimeProperties(IPAICustomProperties **props) = 0;
    virtual HRESULT PDefineUserProperty(LPCWSTR name, LPCWSTR prompt, UINT usein, UINT type, UINT flags, LPCWSTR info) = 0;

    virtual HRESULT PEnumTargetLanguages(int inx, LANGID *lang) = 0;
    virtual HRESULT PExportProject(LPCWSTR filepath, BOOL bLock) = 0;    // saves a copy of the .lpu file 
    virtual HRESULT PImportProject(LPCWSTR filepath, BOOL bUnlock) = 0;  // re-reads the project that has been exported with PExportProject
    
    virtual HRESULT PImportTransBundle(LPCWSTR filepath, DWORD flags) = 0;
    virtual HRESULT PImport(LPCWSTR format, LPCWSTR filepath, DWORD flags) = 0;

    virtual HRESULT PGetGlossary(int inx, PAISTRUCT_GLOSSARY *glossary) = 0;
};


// Internal Property Names for IPAIStringList
#define SLPROP_SOURCEFILE MAKEINTRESOURCEW(-1)


//----------------------------------------------------------------------------
// struct IPAIStringList
// 
//----------------------------------------------------------------------------
struct IPAIStringList
{
    virtual HRESULT SLGetListInfo(/*[out]*/ PAISTRUCT_LISTINFO *listinfo) = 0;
    virtual HRESULT SLGetFileOptions(/*[out]*/ IPAIFileOptions **options) = 0;

    virtual HRESULT SLGetResourceCount(/*[out]*/int *count, BOOL bWithDeleted = TRUE) = 0;
    virtual HRESULT SLGetResource(int index, /*[out]*/ IPAIResource **resource) = 0;
    virtual HRESULT SLFindResource(LPCWSTR type, LPCWSTR name, /*[out]*/ IPAIResource **resource, IPAIResource *parent = NULL) = 0;

    virtual HRESULT SLGetTokenCount(/*[out]*/ int *count, BOOL bWithDeleted = TRUE) = 0;
    virtual HRESULT SLGetToken(int index, /*[out]*/ IPAIToken **token, BOOL bForUpdate = FALSE) = 0;
    virtual HRESULT SLGetTokenInfo(/*[in]*/ int index, /*[out]*/ PAISTRUCT_TOKENINFO *tokeninfo) = 0;
    virtual HRESULT SLGetTokenText(/*[in]*/int index, /*[in]*/int what, /*[out]*/ BSTR *text) = 0;
    virtual HRESULT SLLog(/*[in]*/ int type, /*[in]*/ LPCWSTR text) = 0;

    virtual HRESULT SLStoreResFile(IPAIAddIn *addin, UINT type, LPCWSTR name, LPCWSTR path) = 0;
    virtual HRESULT SLGetResFile(IPAIAddIn *addin, UINT type, LPCWSTR name, LPWSTR path, int npath) = 0;

    virtual HRESULT SLGetDescription(BSTR *text, DWORD flags = 0) = 0;
    virtual HRESULT SLGetProperty(LPCWSTR name, VARIANT *value) = 0;
};


//----------------------------------------------------------------------------
// struct IPAIToken
// Access to a token
//----------------------------------------------------------------------------
struct IPAIToken
{
    virtual HRESULT TSetStringProperty(LPCWSTR name, LPCWSTR value) = 0;
    virtual HRESULT TSetIntProperty(LPCWSTR name, int value) = 0;
    virtual HRESULT TSetBinaryProperty(LPCWSTR name, LPBYTE value, int size) = 0;
    
    virtual HRESULT TDefineStringProperty(LPCWSTR name, LPCWSTR value, UINT flags) = 0;
    virtual HRESULT TDefineIntProperty(LPCWSTR name, int value, UINT flags) = 0;
    virtual HRESULT TDefineBinaryProperty(LPCWSTR name, LPBYTE value, int size, UINT flags) = 0;
    
    virtual HRESULT TGetProperty(LPCWSTR name, VARIANT *value, int select = PROPSEL_DEFAULT) = 0;
    virtual HRESULT TGetCustomProperties(IPAICustomProperties **props, int select = PROPSEL_DEFAULT) = 0;
    virtual HRESULT TUpdate(UINT flags) = 0;  // Used for bForUpdate
    virtual HRESULT TGetStringList(IPAIStringList **stringlist) = 0; 
    virtual HRESULT TGetResource(IPAIResource **resource) = 0;
    virtual HRESULT TDefineReferenceID(LPCWSTR restype, LPCWSTR resname, LPCWSTR id, DWORD flags) = 0;
    virtual HRESULT TDefineReferenceNumber(LONG number, DWORD flags) = 0;
    virtual HRESULT TGetDescription(BSTR *text, DWORD flags = 0) = 0;
    virtual HRESULT TTransformTags(LPCTSTR strFrom, int tagformatFrom, BSTR *strTo, int tagformatTo) = 0;
    virtual HRESULT TIsTranslation(BOOL *bTranslation) = 0;
};

//----------------------------------------------------------------------------
// struct IPAIResource
// Access to current resource
//----------------------------------------------------------------------------
struct IPAIResource
{
    virtual HRESULT RscSetStringProperty(LPCWSTR name, LPCWSTR value) = 0;
    virtual HRESULT RscSetIntProperty(LPCWSTR name, int value) = 0;
    virtual HRESULT RscSetBinaryProperty(LPCWSTR name, LPBYTE value, int size) = 0;
    
    virtual HRESULT RscDefineStringProperty(LPCWSTR name, LPCWSTR value, UINT flags) = 0;
    virtual HRESULT RscDefineIntProperty(LPCWSTR name, int value, UINT flags) = 0;
    virtual HRESULT RscDefineBinaryProperty(LPCWSTR name, LPBYTE value, int size, UINT flags) = 0;
    
    virtual HRESULT RscGetProperty(LPCWSTR name, VARIANT *value, int select = PROPSEL_DEFAULT) = 0;

    virtual HRESULT RscGetListInfo(/*[out]*/ PAISTRUCT_LISTINFO *listinfo, /*[out]*/BOOL *translating) = 0;
    virtual HRESULT RscHandleToken(LPINT inx = NULL, DWORD flags = 0) = 0;
    virtual HRESULT RscLog(/*[in]*/ int type, /*[in]*/ LPCWSTR text) = 0;

    virtual HRESULT RscGetToken(/*[in]*/ int inx, IPAIToken **token, BOOL bForUpdate = FALSE) = 0;
    virtual HRESULT RscGetProject(IPAIProject **project) = 0;
    virtual HRESULT RscGetStringList(IPAIStringList **stringlist) = 0; 

    virtual HRESULT RscGetCustomProperties(IPAICustomProperties **props, int select = PROPSEL_DEFAULT) = 0;
    virtual HRESULT RscStoreResFile(LPCWSTR name, LPCWSTR path) = 0;
    virtual HRESULT RscGetResFile(LPCWSTR name, LPWSTR path, int npath) = 0;
    virtual HRESULT RscIsTranslation(BOOL *bTranslation) = 0;

    virtual HRESULT RscHandleSubResource(LPCWSTR restype, LPCWSTR resname, LANGID langid, IPAIResource **resource, DWORD flags = 0) = 0;
    virtual HRESULT RscHandleInternalSubResource(LPCWSTR restype, LPCWSTR resname, IPAIResData *resdata, IPAIResource **resource = NULL) = 0;
    virtual HRESULT RscCreateResData(LPBYTE mem, DWORD size, BOOL writeable, IPAIResData **resdata) = 0;
    virtual HRESULT RscDestroyResData(IPAIResData *resdata) = 0;
};

//----------------------------------------------------------------------------
// struct IPAITokenSelection
// 
//----------------------------------------------------------------------------
struct IPAITokenSelection
{
    virtual HRESULT TSelGetCount(/*[out]*/LPINT count) = 0;
    virtual HRESULT TSelGetToken(/*[in]*/ int inx, /*[out]*/IPAIToken **token, /*[out]*/ LPINT tokenindex = NULL, BOOL bForUpdate = FALSE) = 0;
    virtual HRESULT TSelGetProject(IPAIProject **project) = 0;
    virtual HRESULT TSelIsSelected(IPAIToken *token) = 0;
    virtual HRESULT TSelGetType(int *type) = 0;
};

//----------------------------------------------------------------------------
// struct IPAIResData
// Access to current resource data
//----------------------------------------------------------------------------
struct IPAIResData
{
    virtual HRESULT RDGetMem(LPBYTE *mem, DWORD *size) = 0;
    virtual HRESULT RDChangeData(LPBYTE dest, DWORD destsize, LPBYTE src, DWORD srcsize, int *delta) = 0;
    virtual HRESULT RDChangeStringW(LPWSTR dest, int destlen, LPCWSTR src, int srclen, int *delta) = 0;
    virtual HRESULT RDChangeStringA(LPSTR dest, int destlen, LPCSTR src, int srclen, int *delta) = 0;
    virtual HRESULT RDReAlign(LPBYTE *ptr, int delta, int align, int *newdelta) = 0;
    virtual HRESULT RDGetCRC(DWORD *crc) = 0;
    virtual HRESULT RDWriteToFile(BSTR *filepath) = 0;
    virtual HRESULT RDReadFromFile(LPCWSTR filepath) = 0;
};



//----------------------------------------------------------------------------
// struct IPAICustomControls
// This interface is provided by the AddIn 
// It's used to create controls for the PASSOLO Dialog Editor
//----------------------------------------------------------------------------
struct IPAICustomControls
{
    // Destroy the controls and the interface
    virtual HRESULT CCDestroy() = 0;

    // Map the Dialog units to pixels or vice versa
    virtual HRESULT CCMapDialogRect(RECT *rect, BOOL bDLUToPixels) = 0; 

    // Returns the Rectangle of a control
    // Return S_FALSE, if the control should not be desplayed
    virtual HRESULT CCGetCtrlRect(int inx, RECT *rc, int type, DWORD flags) = 0;

    // Returns the flags of a single control
    virtual HRESULT CCGetEditFlags(int inx, DWORD *flags) = 0;

    // After changing text, properties or control position
    virtual HRESULT CCUpdateCtrl(int inx, DWORD flags) = 0;

    // Returns base information of dialog display
    virtual HRESULT CCGetInfoData(PAISTRUCT_CCINFO *ccinfo) = 0;

    // Called to handle window messages (see PAISTRUCT_CCINFO.Flags)
    virtual HRESULT CCOnWindowMessage(UINT msg, WPARAM wpar, LPARAM lpar, BOOL *bCancel) = 0;

    // Some controls have been hidden or displayed again
    virtual HRESULT CCUpdateVisibility() = 0;

    // Selection has changed (needs CIF_WANT_SELCHANGE in PAISTRUCT_CCINFO.Flags)
    virtual HRESULT CCOnSelChange(IPAITokenSelection *toksel, BOOL *bRedraw) = 0;

    virtual HRESULT CCIsRightToLeft(int inx, BOOL *bRTL) = 0;
    
    // User is typing text (needs CIF_WANT_TEXTINPUT in PAISTRUCT_CCINFO.Flags)
    virtual HRESULT CCOnTextInput(IPAITokenSelection *toksel, LPCWSTR text) = 0;
    
    // The resource editor decides, if a token is displayed in the string list (needs CIF_WANT_FILTERTOKEN flag)
    virtual HRESULT CCOnFilterToken(int inx, BOOL *bDisplay) = 0;
    
    // store all outstanding data to Passolo string list
    virtual HRESULT CCFlushData() = 0;
    
    // The custom editor is closing
    virtual HRESULT CCOnClose() = 0;
};

//----------------------------------------------------------------------------
// struct IPAICustomEditor
// This interface is provided by the AddIn 
// It's used to create a custom resource editor or visualizer
//----------------------------------------------------------------------------
struct IPAICustomEditor
{
    // Destroy the structure
    virtual HRESULT CEDestroy() = 0;

    // Returns base information of dialog display
    virtual HRESULT CEGetInfoData(PAISTRUCT_CEINFO *ceinfo) = 0;

    // Returns the size of the display (called if SizeMode is CSM_FIXED or CSM_DYNAMIC)
    virtual HRESULT CEGetSize(SIZE *size) = 0;

    // Size of resource editor window has changed (called if SizeMode is CSM_MAXCLIENT)
    virtual HRESULT CEOnSize(SIZE *size) = 0;

    // Paint the resource
    virtual HRESULT CEPaint(HDC dc) = 0;

    // Called to handle window messages (see PAISTRUCT_CCINFO.Flags)
    virtual HRESULT CEOnWindowMessage(UINT msg, WPARAM wpar, LPARAM lpar, BOOL *bCancel) = 0;

    // Selection has changed (needs CIF_WANT_SELCHANGE in PAISTRUCT_CCINFO.Flags)
    virtual HRESULT CEOnSelChange(IPAITokenSelection *toksel, BOOL *bRedraw) = 0;

    // After changing text or properties
    virtual HRESULT CEUpdateCtrl(int inx, DWORD flags) = 0;
    
    // User is typing text (needs CIF_WANT_TEXTINPUT in PAISTRUCT_CCINFO.Flags)
    virtual HRESULT CEOnTextInput(IPAITokenSelection *toksel, LPCWSTR text) = 0;

    // The custom editor decides, if a token is displayed in the string list (needs CIF_WANT_FILTERTOKEN flag)
    virtual HRESULT CEOnFilterToken(int inx, BOOL *bDisplay) = 0;
    
    // store all outstanding data to Passolo string list
    virtual HRESULT CEFlushData() = 0;
    
    // The custom editor is closing
    virtual HRESULT CEOnClose() = 0;
};

//----------------------------------------------------------------------------
// struct IPAICustomFile
// 
//----------------------------------------------------------------------------
struct IPAICustomFile
{
    // Handles a resource while scanning
    virtual HRESULT CFExtractLanguage(LANGID langid, BOOL *bExtract) = 0;
    virtual HRESULT CFHandleResource(LPCWSTR restype, LPCWSTR resname, LANGID langid, IPAIResource **resource, DWORD flags = 0) = 0;

    // Helpers for handling a memory block
    virtual HRESULT CFCreateResData(LPBYTE mem, DWORD size, BOOL writeable, IPAIResData **resdata) = 0;
    virtual HRESULT CFHandleInternalResource(LPCWSTR restype, LPCWSTR resname, IPAIResData *resdata, IPAIResource **resource = NULL) = 0;
    virtual HRESULT CFDestroyResData(IPAIResData *resdata) = 0;

    virtual HRESULT CFGetListInfo(/*[out]*/ PAISTRUCT_LISTINFO *listinfo, /*[out]*/BOOL *translating) = 0;
    virtual HRESULT CFGetProperty(LPCWSTR name, VARIANT *value, int select = PROPSEL_DEFAULT) = 0;
    virtual HRESULT CFGetCustomProperties(IPAICustomProperties **props, int select) = 0;
    virtual HRESULT CFGetProject(IPAIProject **project) = 0;
    virtual HRESULT CFGetStringList(IPAIStringList **stringlist) = 0;

    virtual HRESULT CFSetVirtualTime(FILETIME *ft) = 0;
    virtual HRESULT CFSuggestTargetPathRule(int index) = 0;

    virtual HRESULT CFStoreResFile(LPCWSTR name, LPCWSTR path) = 0;
    virtual HRESULT CFLog(/*[in]*/ int type, /*[in]*/ LPCWSTR text) = 0;
    virtual HRESULT CFGetResFile(LPCWSTR name, LPWSTR path, int npath) = 0;
    
    virtual HRESULT CFIsAborted(BOOL *bAborted) = 0;
};

#define CFListResource(restype, resname, langid) CFHandleResource(restype, resname, langid, NULL);


//----------------------------------------------------------------------------
// struct IPAITokenCheck
// used while checking tokens
//----------------------------------------------------------------------------
struct IPAITokenCheck
{
    virtual HRESULT TCStandardCheck(IPAIToken *tok, LPCWSTR restype) = 0;
    virtual HRESULT TCGetOption(int check, BOOL *bSet) = 0;
    virtual HRESULT TCErrorOutput(IPAIToken *tok, LPCWSTR text, BOOL bResEditor = FALSE) = 0;
    virtual HRESULT TCSetUserData(LPVOID pdata) = 0;
    virtual HRESULT TCGetUserData(LPVOID *pdata) = 0;
    virtual HRESULT TCGetStringList(IPAIStringList **stringlist) = 0;
    virtual HRESULT TCGetProject(IPAIProject **project) = 0;
    virtual HRESULT TCIsFinished(BOOL *bFinished) = 0;
};


//----------------------------------------------------------------------------
// struct IPAIResourceEditor
// Access to current resource editor (lifetime same as IPAICustomControls
//----------------------------------------------------------------------------
struct IPAIResourceEditor
{
    virtual HRESULT REGetWindow(HWND *hwnd, POINT *ptOrigin) = 0;
    virtual HRESULT REGetSelection(IPAITokenSelection **toksel) = 0;
    virtual HRESULT RERebuild() = 0;
    virtual HRESULT RERefillList() = 0;
    virtual HRESULT REUpdateCtrl(int inx, DWORD flags) = 0;
    virtual HRESULT RECtrlVisible(int inx, BOOL *bVisible) = 0;
    virtual HRESULT REGetProject(IPAIProject **project) = 0;
    virtual HRESULT REGetStringList(IPAIStringList **stringlist) = 0;
    virtual HRESULT RESelect(int inx, BOOL bSelect = TRUE, BOOL bMerge = FALSE) = 0;
    virtual HRESULT REScrollIntoView(RECT *rect) = 0;
    virtual HRESULT REGetClientSize(SIZE *size) = 0;
    virtual HRESULT REGetCurrentDisplay(int *select) = 0;
    virtual HRESULT REGetStandardResourceInfo(IPAIStandardResourceInfo **info) = 0;
    virtual HRESULT REGetScrollPosition(POINT *pt) = 0;
    virtual HRESULT RESelectToken(IPAIToken *token, BOOL bSelect = TRUE, BOOL bMerge = FALSE) = 0;
    virtual HRESULT REPaintSelectionFrame(HDC hDC, RECT *rect, UINT handles = 0xFFFF) = 0;
};

//----------------------------------------------------------------------------
// struct IPAITranslationFields
// 
//----------------------------------------------------------------------------
struct IPAITranslationFields
{
    virtual HRESULT TFGetFeildsCount(int *count) = 0;
    virtual HRESULT TFGetField(int index, LPCWSTR *name, LPCWSTR *value) = 0;
};

//----------------------------------------------------------------------------
// struct IPAITranslations
// used to obtain information and pass translations 
//----------------------------------------------------------------------------
struct IPAITranslations
{
    virtual HRESULT TRGetSourceString(BSTR *str) = 0;
    virtual HRESULT TRGetToken(/*[out]*/ IPAIToken **token) = 0;
    virtual HRESULT TRGetType(int *type) = 0;
    virtual HRESULT TRGetLanguages(LANGID *lang1, LANGID *lang2) = 0;
    virtual HRESULT TRAddTranslation(LPCWSTR trnstr, LPCWSTR srcstr = NULL, int match = 100, LPCWSTR origin = NULL) = 0;
    virtual HRESULT TRAddTranslationEx(LPCWSTR trnstr, LPCWSTR srcstr = NULL, int match = 100, LPCWSTR origin = NULL, IPAITranslationFields *fields = NULL) = 0;
    virtual HRESULT TRAddConcordance(LPCWSTR srcstr, int from, int len, LPCWSTR trnstr, int match = 100, LPCWSTR origin = NULL) = 0;
    virtual HRESULT TRAddConcordanceEx(LPCWSTR srcstr, int from, int len, LPCWSTR trnstr, int match = 100, LPCWSTR origin = NULL, IPAITranslationFields *fields = NULL) = 0;
    virtual HRESULT TRAddTerminology(int from, int len, LPCWSTR source, LPCWSTR trans, LPCWSTR origin = NULL, LPCWSTR definition = NULL) = 0;
    virtual HRESULT TRContinue() = 0;
    virtual HRESULT TRGetMatchFlags(UINT *flags) = 0;
    virtual HRESULT TRCompareSourceString(LPCWSTR str, BOOL *bMatch) = 0;
    virtual HRESULT TRGetProject(IPAIProject **project) = 0;
    virtual HRESULT TRGetAsyncCookie(long *cookie) = 0;
    virtual HRESULT TRGetGlossaries(LANGID langFrom, LANGID langTo, BSTR *glossaries, int type = TRANS_DEFAULT) = 0;
    
    // Only used by Glossary Translation
    virtual HRESULT TRGetOption(int transoption, int *value) = 0;
    virtual HRESULT TRGetGlossaryProvider(int inx, PAISTRUCT_GLOSSARY *glossary, IPAIProject **project) = 0;
    virtual HRESULT TRAddProjectTranslation(DWORD projectid, LPCWSTR tmid, int match) = 0;
    virtual HRESULT TRAddProjectConcordance(DWORD projectid, LPCWSTR tmid, LPCWSTR srcstr, int from, int len, int match = 100) = 0;
    virtual HRESULT TRAddProjectTerminology(DWORD projectid, LPCWSTR tmid, LPCWSTR srcstr, int from, int len, LPCWSTR definition = NULL, int match = 100) = 0;
};

//----------------------------------------------------------------------------
// struct IPAISpellCheckResult
// 
//----------------------------------------------------------------------------
struct IPAISpellCheckResult 
{
    virtual HRESULT SCRSetOK() = 0; 
    virtual HRESULT SCRSetError() = 0; 
    virtual HRESULT SCRSetCorrection(LPCWSTR correction) = 0;
    virtual HRESULT SCRAddSuggestion(LPCWSTR suggestion) = 0;
    virtual HRESULT SCRAbort() = 0;
};

//----------------------------------------------------------------------------
// struct IPAISpellCheck
// Provided from the Addin for SpellChecking
//----------------------------------------------------------------------------
struct IPAISpellCheck
{
    virtual HRESULT SCSetLanguage(LANGID langid, UINT codepage) = 0;
    virtual HRESULT SCSetCustomDictionaries(int count, LPCWSTR *paths) = 0;
    virtual HRESULT SCCheckSpelling(LPCWSTR word,  DWORD flags, IPAISpellCheckResult *result) = 0;
    virtual HRESULT SCCheckWithDialog(LPCWSTR text, IPAISpellCheckResult *result) = 0;
    virtual HRESULT SCDestroy() = 0;
};



#define PD_INDEX  (-2147483647 - 1)



//----------------------------------------------------------------------------
// struct IPAIPropertyDefinitions
// Used from Addin to set definitions for a set of properties
//----------------------------------------------------------------------------
struct IPAIPropertyDefinitions
{
    virtual HRESULT PDGetCustomProperties(IPAICustomProperties **props) = 0;
    virtual HRESULT PDGetPropertyCount(int *count) = 0;
    virtual HRESULT PDGetPropertyName(int inx, LPCWSTR *name) = 0;
    virtual HRESULT PDGetResType(LPCWSTR *restype) = 0;
    virtual HRESULT PDGetProject(IPAIProject **project) = 0;

    virtual HRESULT PDSetPrompt(int inx, LPCWSTR prompt) = 0;
    virtual HRESULT PDSetType(int inx, UINT type) = 0;
    virtual HRESULT PDSetFlags(int inx, UINT flags) = 0;
    virtual HRESULT PDAddChoice(int inx, LPCWSTR str, int value = PD_INDEX) = 0;
    virtual HRESULT PDSetInfo(int inx, LPCWSTR info) = 0;
};



//----------------------------------------------------------------------------
// struct IPAITokenSegments
// 
//----------------------------------------------------------------------------
struct IPAITokenSegments
{
    virtual HRESULT TSGetSegToken(IPAIToken **segtoken) = 0;
    virtual HRESULT TSHandleSegToken(int nSegmentNumber, int nFrom, int nLen) = 0;
};


//----------------------------------------------------------------------------
// struct IPAISegmenter
// 
//----------------------------------------------------------------------------
struct IPAISegmenter
{
    virtual HRESULT SMakeSegments(IPAIToken *token, int action, IPAITokenSegments *segments) = 0;
    virtual HRESULT SDestroy() = 0;
};

//----------------------------------------------------------------------------
// struct IPAIApplicationTools
// 
//----------------------------------------------------------------------------
struct IPAIApplicationTools
{
    virtual HRESULT ATFindLanguageFile(LPCWSTR filename, HINSTANCE hCheckVersion, LPWSTR path, int npath) = 0;
    //virtual HRESULT _ATCheck(int v1, LPVOID v2, int v3, int v4) = 0; /* internal usage */
    virtual HRESULT ATLog(int type, LPCWSTR text) = 0;
    virtual HRESULT ATLogRef(int type, IPAIToken *tok, LPCWSTR text) = 0;
    virtual HRESULT ATDisplayAlerts(int type, BOOL *bDisplay) = 0;

    virtual HRESULT ATGetProperty(LPCWSTR name, VARIANT *value) = 0;
    virtual HRESULT ATGetRuntimeProperties(IPAICustomProperties **props) = 0;
    virtual HRESULT ATGetEditionString(BSTR *str, UINT type = PAIEDITION_DEFAULT) = 0;
	virtual HRESULT ATGetInstanceID(BSTR *str) = 0;

    virtual HRESULT ATGetLangCode(LANGID langid, BSTR *codestr, int type) = 0;
    virtual HRESULT ATGetDefaultCodePage(LANGID langid, UINT *codepage) = 0;
    virtual HRESULT ATGetLangID(LPCWSTR langcode, int type, LANGID *langid) = 0;
    virtual HRESULT ATEnumLanguages(int inx, LANGID *lang) = 0;
    virtual HRESULT ATDrawLanguageFlag(HDC dc, RECT *rect, LANGID langid, BOOL bWithName) = 0;
    
    virtual HRESULT ATCreateRegularExpression(IPAIRegularExpression **regexp, LPCWSTR pattern = NULL, DWORD flags = 0) = 0;

    virtual HRESULT ATEnumProjects(int inx, IPAIProject **project) = 0;
    virtual HRESULT ATGetCurProject(IPAIProject **project) = 0;
	virtual HRESULT ATGetTempProjectFolder(LPWSTR path, int npath) = 0;
	virtual HRESULT ATOpenProject(LPWSTR pathProject) = 0;
	virtual HRESULT ATOpenTempProject(LPWSTR pathTempProject, int npath, LPWSTR pathProject) = 0;
	virtual HRESULT ATCloseProject() = 0;
	virtual HRESULT ATCloseTempProject() = 0;
    virtual HRESULT ATGetCurResource(IPAIResource **res, int select = PROPSEL_DEFAULT) = 0;
    virtual HRESULT ATGetCurSelection(IPAITokenSelection **sel, int select = PROPSEL_DEFAULT) = 0;

    virtual HRESULT ATSendTerminology(IPAIAddIn *addin, long cookie, int from, int len, LPCWSTR source, LPCWSTR trans, LPCWSTR origin = NULL, LPCWSTR definition = NULL) = 0;
    virtual HRESULT ATSendTerminologyEx(IPAIAddIn *addin, long cookie, int from, int len, LPCWSTR source, LPCWSTR trans, LPCWSTR origin = NULL, LPCWSTR definition = NULL, LPCWSTR sourceDescriptors = NULL, LPCWSTR transDescriptors = NULL, LPCWSTR transMenuInfo = NULL, bool forbidden = false) = 0;
    virtual HRESULT ATSendTranslation(IPAIAddIn *addin, long cookie, LPCWSTR trnstr, LPCWSTR srcstr = NULL, int match = 100, LPCWSTR origin = NULL) = 0;
    virtual HRESULT ATSendTranslationEx(IPAIAddIn *addin, long cookie, LPCWSTR trnstr, LPCWSTR srcstr = NULL, int match = 100, LPCWSTR origin = NULL, IPAITranslationFields *fields = NULL) = 0;
    virtual HRESULT ATSendConcordance(IPAIAddIn *addin, long cookie, LPCWSTR srcstr, int from, int len, LPCWSTR trnstr, int match = 100, LPCWSTR origin = NULL) = 0;
    virtual HRESULT ATSendConcordanceEx(IPAIAddIn *addin, long cookie, LPCWSTR srcstr, int from, int len, LPCWSTR trnstr, int match = 100, LPCWSTR origin = NULL, IPAITranslationFields *fields = NULL) = 0;

    virtual HRESULT ATNotifyProgress(long cookie,  int progress) = 0;
    virtual HRESULT ATNotifyAbort(long cookie, LPCWSTR message = NULL) = 0;
    virtual HRESULT ATNotifyOpenExtFiles(long cookie, PAISTRUCT_NOTIFY_OPEN_EXT_FILES *data) = 0;
    virtual HRESULT ATNotifyStoreExtFiles(long cookie, PAISTRUCT_NOTIFY_STORE_EXT_FILES *data) = 0;

    virtual HRESULT ATGetGlossary(int inx, PAISTRUCT_GLOSSARY *glossary) = 0;
    
    // Only used by Glossary AddIns
    virtual HRESULT ATSendProjectTerminology(long cookie, DWORD projectid, LPCWSTR tmid, LPCWSTR srcstr, int from, int len, LPCWSTR definition = NULL) = 0;
    virtual HRESULT ATSendProjectTranslation(long cookie, DWORD projectid, LPCWSTR tmid, LPCWSTR srcstr = NULL, int match = 100) = 0;
    virtual HRESULT ATSendProjectConcordance(long cookie, DWORD projectid, LPCWSTR tmid, LPCWSTR srcstr, int from, int len, int match = 100) = 0;
    
    // Communication with macros
    virtual HRESULT ATRunMacroFile(LPCWSTR filename, BOOL bRefreshProject) = 0;
    virtual HRESULT ATRunBasicScript(LPCWSTR script, BSTR *error) = 0;
    virtual HRESULT ATFireMacroEvent(LONG lpar, LPCWSTR strpar, LONG *result) = 0;
    virtual HRESULT _ATInternalMessage(LPCWSTR command, LONG lpar, LPCWSTR strpar, LONG *result) = 0;
};


#pragma region Glossaries

//--------------------------------------------------------------------------------
/// <summary>
/// Defines where the glossary comes from
/// </summary>
//--------------------------------------------------------------------------------
enum PAIGlossContext
{
    GLOSSCONTEXT_COMMON   = 0,  // Common glossary
    GLOSSCONTEXT_PROJECT  = 1,  // Project glossary (not embedded in project file)
    GLOSSCONTEXT_EMBEDDED = 2,  // Embedded project glossary
};

//--------------------------------------------------------------------------------
/// <summary>
/// Defines the states of a glossary, set by the add-in in GTGetGlossaryState
/// </summary>
//--------------------------------------------------------------------------------
enum PAIGlossState
{
    GLOSSSTATE_UNKNOWN         = 0,
    GLOSSSTATE_NO_INDEX        = 1,
    GLOSSSTATE_INDEXING        = 2,
    GLOSSSTATE_INDEXED_OK      = 3,
    GLOSSSTATE_INDEXED_INVALID = 4,
    GLOSSSTATE_ERROR           = 5,
};

//--------------------------------------------------------------------------------
/// <summary>
/// 
/// </summary>
//--------------------------------------------------------------------------------
enum PAISyncBundleMode
{
    SYNCBUNDLE_UNKNOWN      = 0, // unknown mode 
    SYNCBUNDLE_EXPORT       = 1, // Exporting translation bundle
    SYNCBUNDLE_IMPORT       = 2, // Importing translation bundle (not used yet)
    SYNCBUNDLE_WRITE_UPDATE = 3, // Writing bundle update file
    SYNCBUNDLE_READ_UPDATE  = 4, // Reading bundle update file
    SYNCBUNDLE_WRITE_TRANS  = 5, // Writing translation file
    SYNCBUNDLE_READ_TRANS   = 6, // Reading translation file
};   


//--------------------------------------------------------------------------------
/// <summary>
/// Contains information about a glossary (for ATGetGlossary and PGetGlossary)
/// </summary>
//--------------------------------------------------------------------------------
struct PAISTRUCT_GLOSSARY
{
    WCHAR Path[256];   // Absolute Path of Glossary
    int   Context;     // GLOSSCONTEXT_COMMON, GLOSSCONTEXT_PROJECT or GLOSSCONTEXT_EMBEDDED
    int   TransType;   // What is this glossary used for? Combination of TRANS_AUTOTRANS, TRANS_FUZZYMATCH, TRANS_CONCORDANCE and TRANS_TERMINOLOGY
    BOOL  Enabled;     // TRUE = the glossary is enabled, FALSE = the glossary is disabled (locked)
    
    // Set by addin in GTGetIndexState
    int   State;            // GLOSSSTATE_...
    WCHAR StateMessage[80]; // Additional information, e.g. error with GLOSSSTATE_ERROR, percentage with GLOSSSTATE_INDEXING
    BOOL  Open;             // TRUE = The index is currently opened
    int   Size;             // Number of entries
};

//--------------------------------------------------------------------------------
/// <summary>
/// Provided from a Glossary Translator Addin
/// </summary>
//--------------------------------------------------------------------------------
struct IPAIGlossaryTranslator
{
    virtual HRESULT GTInitialize() = 0;
    virtual HRESULT GTDestroy() = 0;
    virtual HRESULT GTGetIndexState(FILETIME *timestamp, PAISTRUCT_GLOSSARY *glossary, IPAIProject *project) = 0;
    virtual HRESULT GTCreateGlossaryIndex(PAISTRUCT_GLOSSARY *glossary, IPAIProject *project) = 0;
    virtual HRESULT GTCreateProjectIndex(LPCWSTR csvpath, IPAIProject *project) = 0;
    virtual HRESULT GTCloseGlossary(PAISTRUCT_GLOSSARY *glossary, IPAIProject *project) = 0;
    virtual HRESULT GTTranslateFromGlossary(PAISTRUCT_GLOSSARY *glossary, IPAIProject *project, LPCWSTR str, int minmatch, IPAITranslations *trans) = 0;
    virtual HRESULT GTTranslateFromProject(IPAIProject *project, LPCWSTR str, int minmatch, IPAITranslations *trans) = 0;
    virtual HRESULT GTOnAddGlossary(PAISTRUCT_GLOSSARY *glossary, IPAIProject *project) = 0;
    virtual HRESULT GTOnRemoveGlossary(PAISTRUCT_GLOSSARY *glossary, IPAIProject *project) = 0;
    virtual HRESULT GTOnManageGlossaries() = 0;
    virtual HRESULT GTStoreTranslation(PAISTRUCT_GLOSSARY *glossary, IPAIProject *project, LPCWSTR srcstr, LPCWSTR trnstr, LANGID lang1, LANGID lang2, int cat) = 0;
};

#pragma endregion 

//--------------------------------------------------------------------------------
/// <summary>
/// 
/// </summary>
//--------------------------------------------------------------------------------
struct PAISTRUCT_TRANSCONNECTION
{
    WCHAR ID[300];     // An identifier for this connection
    WCHAR Name[100];   // The name displayed to the user
    DWORD Type;        // Combination of TRANS_AUTOTRANS, TRANS_FUZZYMATCH, TRANS_CONCORDANCE and TRANS_TERMINOLOGY
    DWORD ActiveTypes; // Which types are currently active? 
};

//////////////////////////////////////////////////////////////////////////////
// AddIn-Functions
// 
//////////////////////////////////////////////////////////////////////////////

//----------------------------------------------------------------------------
// For each AddIn
//----------------------------------------------------------------------------

// "PAIFN_LoadAddIn" (The very first function called, used to check the interface versions
typedef HRESULT (*PAIFNTYPE_LoadAddIn) (PAISTRUCT_INTERFACE_VERSION *ver);

// "PAIFN_Initialize"
typedef HRESULT (*PAIFNTYPE_Initialize) (/*[in,out]*/ PAISTRUCT_INIT *init, IPAIApplicationTools *apptools, IPAIAddIn *addin);

// "PAIFN_Setup"
typedef HRESULT (*PAIFNTYPE_Setup) ();

// "PAIFN_GetErrorText"
typedef HRESULT (*PAIFNTYPE_GetErrorText) (HRESULT hr, LPWSTR text, int ntext);

// "PAIFN_GetHelpFile" (optional)
typedef HRESULT (*PAIFNTYPE_GetHelpFile) (LPCWSTR path, int npath, LPDWORD context);

// "PAIFN_About" (optional)
typedef HRESULT (*PAIFNTYPE_About) (HWND hParent, BSTR *text);

// "PAIFN_OnMacroMessage" (optional)
typedef HRESULT (*PAIFNTYPE_OnMacroMessage) (LPCWSTR command, LONG lpar, LPCWSTR strpar, LONG *result);

// "PAINF_Exit" (optional)
typedef HRESULT (*PAIFNTYPE_Exit) ();

// "PAIFN_DisregardFunction
typedef HRESULT (*PAIFNTYPE_DisregardFunction) (LPCWSTR name, BOOL *pbDisregard);

// "PAIFN_AbortFunction
typedef HRESULT (*PAIFNTYPE_AbortFunction) (long cookie);

// "PAIFN_OnProjectEvent
typedef HRESULT (*PAIFNTYPE_OnProjectEvent) (int nEvent, IPAIProject *project);

// "PAIFN_OnTokenEvent
typedef HRESULT (*PAIFNTYPE_OnTokenEvent) (int nEvent, IPAIProject *project, IPAIToken *token);

// "PAIFN_ExportSettings"
typedef HRESULT (*PAIFNTYPE_ExportSettings) (LPCWSTR path, int reason);

// "PAIFN_ImportSettings"
typedef HRESULT (*PAIFNTYPE_ImportSettings) (LPCWSTR path, int reason);

// "PAIFN_GetIconHandle"
typedef HRESULT (*PAIFNTYPE_GetIconHandle) (LPCWSTR id, BOOL bLarge, HICON *hIcon);

// "PAIFN_AddinControl" (optional)
typedef HRESULT (*PAIFNTYPE_AddinControl) (LPCWSTR command, LONG *param1, BSTR *param2);

//----------------------------------------------------------------------------
// Export
//----------------------------------------------------------------------------

// "PAIFN_GetExpImpData"
typedef HRESULT (*PAIFNTYPE_GetExpImpData) (PAISTRUCT_EXPIMPDATA *expimpdata);

// "PAIFN_BeginExport"
typedef HRESULT (*PAIFNTYPE_BeginExport) ();

// "PAIFN_Export"
typedef HRESULT (*PAIFNTYPE_Export) (LPCWSTR filename, IPAIExport *callback);

// "PAIFN_EndExport"
typedef HRESULT (*PAIFNTYPE_EndExport) ();

// "PAIFN_GetExportWriter" // replaces BeginExport,Export,EndExport
typedef HRESULT (*PAIFNTYPE_GetExportWriter) (IPAIExportWriter **expwriter);

//----------------------------------------------------------------------------
// Import
//----------------------------------------------------------------------------

// "PAIFN_Import"
typedef HRESULT (*PAIFNTYPE_Import) (LPCWSTR filename, IPAIImport *callback);

//----------------------------------------------------------------------------
// Custom Resource
//----------------------------------------------------------------------------

// "PAIFN_RscCheckType"
typedef HRESULT (*PAIFNTYPE_RscCheckType) (LPCWSTR restype, IPAIResData *resdata);

// "PAIFN_RscScan"
typedef HRESULT (*PAIFNTYPE_RscScan) (LPCWSTR restype, IPAIResource *resource, IPAIResData *resdata, int action);

// "PAIFN_CreateCustomControls" (optional)
typedef HRESULT (*PAIFNTYPE_CreateCustomControls) (IPAIResourceEditor *resedit, IPAIResource *resource, IPAICustomControls **pfn);

// "PAIFN_AdjustControlFont" (optional)
typedef HRESULT (*PAIFNTYPE_AdjustControlFont) (IPAIToken *tokDlg, IPAIToken *tokCtrl);

// "PAIFN_CreateCustomEditor" (optional)
typedef HRESULT (*PAIFNTYPE_CreateCustomEditor) (IPAIResourceEditor *resedit, IPAIResource *resource, IPAICustomEditor **pfn);

// "PAIFN_GetTargetPathRule" (optional)
typedef HRESULT (*PAIFNTYPE_GetTargetPathRule) (int index, BSTR *name, BSTR *desc, BSTR *path);

// "PAIFN_QueryTargetPath" (optional)
typedef HRESULT (*PAIFNTYPE_QueryTargetPath) (LPCWSTR par, LPCWSTR projectpath, LPCWSTR srcpath, LANGID langid, BSTR *result);

// "PAIFN_EditCustomProperties" (optional)
typedef HRESULT (*PAIFNTYPE_EditCustomProperties) (HWND hParent, IPAITokenSelection *toksel, int select);

// "PAIFN_UpdateCustomProperties" (optional)
typedef HRESULT (*PAIFNTYPE_UpdateCustomProperties) (IPAIToken *srctok, IPAIToken *trntok);

// "PAIFN_GetPropertyDefinitions" (optional)
typedef HRESULT (*PAIFNTYPE_GetPropertyDefinitions) (LPCWSTR *names, int count, IPAIPropertyDefinitions *propdefs);

// "PAIFN_BeginCheckTokens" (optional)
typedef HRESULT (*PAIFNTYPE_BeginCheckTokens) (IPAIResource *resource, IPAITokenCheck *checker);

// "PAIFN_CheckToken" (optional)
typedef HRESULT (*PAIFNTYPE_CheckToken) (IPAIToken *tok, IPAIResource *resource, IPAITokenCheck *checker);

// "PAIFN_EndCheckTokens" (optional)
typedef HRESULT (*PAIFNTYPE_EndCheckTokens)(IPAIResource *resource, IPAITokenCheck *checker);

// "PAIFN_GetCustomCheckOption" (optional)
typedef HRESULT (*PAIFNTYPE_GetCustomCheckOption)(int check, BSTR *text);

// "PAIFN_TagString" (optional)
typedef HRESULT (*PAIFNTYPE_TagString)(LPCWSTR str, BSTR *tagstr, int reason, int tagmode, DWORD flags);

// "PAIFN_UntagString" (obligatory if TagString is implemented)
typedef HRESULT (*PAIFNTYPE_UntagString)(LPCWSTR tagstr, BSTR *str, int reason, int tagmode, DWORD flags);

// "PAIFN_GetCommonTag" (optional)
typedef HRESULT (*PAIFNTYPE_GetCommonTag)(int index, BSTR *name, BSTR *tagstrLeft, BSTR *tagstrRight, int reason, DWORD flags);
   
// "PAIFN_GetResourceDisplays" (optional)
typedef HRESULT (*PAIFNTYPE_GetResourceDisplays)(IPAIResource *resource, PAISTRUCT_RESOURCEDISPLAY displays[16], int *count);

// "PAIFN_GetStandardResourceInfo" (optional)
typedef HRESULT (*PAIFNTYPE_GetStandardResourceInfo)(IPAIResource *resource, DWORD idDisplay, IPAIStandardResourceInfo **data);


//----------------------------------------------------------------------------
// Custom Parsers
//----------------------------------------------------------------------------

// "PAIFN_GetCustomParserData"
typedef HRESULT (*PAIFNTYPE_GetCustomParserData) (PAISTRUCT_CUSTOMPARSERDATA *customparserdata);

// "PAIFN_ParseFile"
typedef HRESULT (*PAIFNTYPE_ParseFile) (LPCWSTR filename, int action, IPAICustomFile *customfile);

// "PAIFN_EditCustomFileOptions"
typedef HRESULT (*PAIFNTYPE_EditCustomFileOptions) (IPAIFileOptions **opts, int numopts, int select);

// "PAIFN_EditCustomRscOptions"
typedef HRESULT (*PAIFNTYPE_EditCustomRscOptions) (IPAIResource **rscs, int numrsc);



//----------------------------------------------------------------------------
// Translation
//----------------------------------------------------------------------------

// "PAIFN_GetTranslateData
typedef HRESULT (*PAIFNTYPE_GetTranslateData) (PAISTRUCT_TRANSLATEDATA *transdata);

// "PAIFN_Translate"  (synchronous or asynchronous)
typedef HRESULT (*PAIFNTYPE_Translate) (LPCWSTR str, int minmatch, int maxcount, IPAITranslations *trans);

// "PAIFN_GetTerminology" (asynchronous, calls ATSendTerminology() for results
typedef HRESULT (*PAIFNTYPE_GetTerminology) (LPCWSTR str, IPAITranslations *trans, long cookie, int minMatch, int maxDepth);

// "PAIFN_SearchTerminology" 
typedef HRESULT (*PAIFNTYPE_SearchTerminology) (LPCWSTR term, IPAITranslations *trans);

// "PAIFN_GetSyncTerminology" (synchronous)
typedef HRESULT (*PAIFNTYPE_GetSyncTerminology) (LPCWSTR str, IPAITranslations *trans);

// "PAIFN_GetConcordances"  (synchronous or asynchronous)
typedef HRESULT (*PAIFNTYPE_GetConcordances) (LPCWSTR str, int minmatch, int maxcount, IPAITranslations *trans);

// "PAIFN_StoreTranslation"
typedef HRESULT (*PAIFNTYPE_StoreTranslation) (LPCWSTR srcstr, LPCWSTR trnstr, LANGID lang1, LANGID lang2, int cat, IPAIToken *crtToken);

// "PAIFN_LookupTerminology"
typedef HRESULT (*PAIFNTYPE_LookupTerminology) (LPCWSTR str, LANGID lang1, LANGID lang2);

// "PAIFN_StoreTerminology"
typedef HRESULT (*PAIFNTYPE_StoreTerminology) (LPCWSTR srcstr, LPCWSTR trnstr, LANGID lang1, LANGID lang2);

// "PAIFN_GetTransConnection"
typedef HRESULT (*PAIFNTYPE_GetTransConnection) (int inx, PAISTRUCT_TRANSCONNECTION *connection);

// "PAIFN_ActivateTransConnection"
typedef HRESULT (*PAIFNTYPE_ActivateTransConnection) (LPCWSTR id, DWORD type, BOOL bActive);

// "PAIFN_SetHitlist"
typedef HRESULT (*PAIFNTYPE_SetHitlist) ();

// "PAIFN_UpdateExistingTranslations"
typedef HRESULT (*PAIFNTYPE_UpdateExistingTranslations) (BOOL overwrite);

//----------------------------------------------------------------------------
// Glossary Translation
//----------------------------------------------------------------------------

// "PAIFN_GetGlossaryTranslator (PASSOLO internal)"
typedef HRESULT (*PAIFNTYPE_GetGlossaryTranslator) (IPAIGlossaryTranslator **glossarytranslator);

//----------------------------------------------------------------------------
// Spell Checking
//----------------------------------------------------------------------------

// "PAIFN_GetSpellCheckData"
typedef HRESULT (*PAIFNTYPE_GetSpellCheckData) (LANGID langid, PAISTRUCT_SPELLCHECKDATA *spellcheckdata);

// "PAIFN_GetSpellChecker"
typedef HRESULT (*PAIFNTYPE_GetSpellChecker) (IPAISpellCheck **spellcheck);


//----------------------------------------------------------------------------
// Segmentation
//----------------------------------------------------------------------------

// "PAIFN_GetSegmenter
typedef HRESULT (*PAIFNTYPE_GetSegmenter) (LANGID langid, IPAISegmenter **segmenter);


//----------------------------------------------------------------------------
// Tools
//----------------------------------------------------------------------------

// "PAIFN_GetToolInfo
typedef HRESULT (*PAIFNTYPE_GetToolInfo) (int nIndex, PAISTRUCT_TOOLINFO *toolinfo);

// "PAIFN_GetExecuteTool
typedef HRESULT (*PAIFNTYPE_ExecuteTool) (int nIndex, IPAIApplicationTools *apptools);

// "PAIFN_ToolOptimizeLayout (Tool implements dialog layout optimization, must set ToolInfo.m_nFlags to TT_OPTIMIZELAYOUT)
typedef HRESULT (*PAIFNTYPE_ToolOptimizeLayout) (int nIndex, IPAIResource *resource, PAISTRUCT_OPTIMIZELAYOUT *options);

// "PAIFN_ToolOpenExtProject (set ToolInfo.m_nFlags to TT_EXTPROJECT)
typedef HRESULT (*PAIFNTYPE_ToolOpenExtProject) (LPCWSTR openid, IPAIExtProject **extproject);

// "PAIFN_ToolGetTaggingData(set ToolInfo.m_nFlags to TT_TAGGING)
typedef HRESULT (*PAIFNTYPE_ToolGetTaggingData) (int tagformat, PAISTRUCT_TAGGING *data);

// "PAIFN_ToolGetExportTargetData(set ToolInfo.m_nFlags to TT_EXPORTTARGET)
typedef HRESULT (*PAIFNTYPE_ToolGetExportTargetData) (LPCTSTR format, PAISTRUCT_EXPORTTARGET_DATA *data);

// "PAIFN_ToolHandleExport(set ToolInfo.m_nFlags to TT_EXPORTTARGET)
typedef HRESULT (*PAIFNTYPE_ToolHandleExport) (LPCTSTR format, IPAIProject *project, PAISTRUCT_EXPORTTARGET_FILE *files, int count);

// "PAIFN_ToolSynchronizeBundle(set ToolInfo.m_nFlags to TT_EXPORTTARGET)
typedef HRESULT (*PAIFNTYPE_ToolSynchronizeBundle) (IPAIProject *project, PAISTRUCT_EXPORTTARGET_FILE *sync, int count, BOOL bSilent);


//----------------------------------------------------------------------------
// AddIn Collection
//----------------------------------------------------------------------------

// "PAIFN_EnumAddIns
typedef HRESULT (*PAIFNTYPE_EnumAddIns) (int nIndex, PAISTRUCT_ADDININFO *addininfo);

// "PAIFN_SwitchAddIn
typedef HRESULT (*PAIFNTYPE_SwitchAddIn) (DWORD nID);

//////////////////////////////////////////////////////////////////////////////
// Error/Return Codes
// 
//////////////////////////////////////////////////////////////////////////////

#define MAKE_PAIERR(n) MAKE_HRESULT(SEVERITY_ERROR, FACILITY_ITF, 100 + n)

#define PAIERR_FIRST        MAKE_PAIERR(0)    // First valid error number
#define PAIERR_LAST         MAKE_PAIERR(299)  // Last valid error number

// Common
#define PAIERR_ERROR        MAKE_PAIERR(0)    // Unspecified add-in error
#define PAIERR_CODEPAGE     MAKE_PAIERR(1)    // Missing codepage
#define PAIERR_NOMATCH      MAKE_PAIERR(2)    // No match for regular expression
#define PAIERR_REFER        MAKE_PAIERR(3)    // PAIFN_Initializes refers to another file to be loaded
#define PAIERR_EXCEPTION    MAKE_PAIERR(4)    // Unhandled exception
#define PAIERR_APPDOMAIN    MAKE_PAIERR(5)    // .NET: Function is called in non-default domain
#define PAIERR_ABORTED      MAKE_PAIERR(6)    // Operation has been aborted

#define PAIERR_NO_FEATURE   MAKE_PAIERR(20)   // Requested feature is not available 

// Export / Import
#define PAIERR_EXP_INDEX    MAKE_PAIERR(40)   // Invalid token index

#define PAIERR_IMP_INVID    MAKE_PAIERR(50)   // Invalid doc id
//#define PAIERR_IMP_DBLID    MAKE_PAIERR(51)   // Multiple call to DefineID
#define PAIERR_IMP_NUMBER   MAKE_PAIERR(52)   // Cannot find token number
#define PAIERR_IMP_NOACCESS MAKE_PAIERR(53)   // Token is hidden or read-only

// Custom Resources
#define PAIERR_RSC_NOSCAN    MAKE_PAIERR(60)   // Addin does not scan this resource type
#define PAIERR_RSC_MEMORY    MAKE_PAIERR(61)   // Resource block needs to be resized
#define PAIERR_RSC_SCANERROR MAKE_PAIERR(62)   // Scan error in custom resource

// Parsers
#define PAIERR_PARSE_CHECKOK      MAKE_PAIERR(70) // Addin wants to parse source file
#define PAIERR_PARSE_DUPLICATE    MAKE_PAIERR(71) // Resource with same ID already scanned
#define PAIERR_PARSE_MISSINGADDIN MAKE_PAIERR(72) // A custom resource parser is missing

// Segmenter
#define PAIERR_SEGMENT_NONE       MAKE_PAIERR(80) // The string is not segmented

// Tools
#define PAIERR_INVALID_EXPORT_ID  MAKE_PAIERR(90) // PImportProject tries to read a project that does not match


// Glossary Translation
#define PAIERR_GLOSSARY_NOINDEX  MAKE_PAIERR(180) // No index has been created yet


// Error Codes defined by the AddIn
#define PAIERR_USERFIRST MAKE_PAIERR(200)
#define PAIERR_USERLAST  MAKE_PAIERR(299)


#pragma pack(pop)
#endif
