﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Pass.AddIn.Framework;
using Pass.AddIn.Core;
using System.Drawing;
using System.IO;

namespace DnContextViewer
{
    //--------------------------------------------------------------------------------
    /// <summary>
    /// Our implementation of a Passolo IPAINetCustomEditor
    /// </summary>
    //--------------------------------------------------------------------------------
    class HtmlView : IPAINetCustomEditor
    {
        HtmlControl _Form;

        //********************************************************************************
        /// <summary>
        /// Implementation of a Html Viewer as IPAINetCustomEditor
        /// </summary>
        /// <param name="editor">The Passolo resource editor. Frame for this viewer</param>
        /// <returns></returns>
        //********************************************************************************
        public HtmlView(CPAIResourceEditor editor)
        {
            try
            {
                _Form = new HtmlControl();
                _Form.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
                _Form.Dock = System.Windows.Forms.DockStyle.Fill; 
                editor.SetChild(_Form, false); 
                _Form.Hide();
            }
            catch (System.Exception)
            {
            	    
            }
        }

        //********************************************************************************
        /// <summary>
        /// Called by Passolo when the resource editor is closed
        /// </summary>
        /// <returns></returns>
        //********************************************************************************
        public int Destroy()
        {
            if (_Form != null)
            {
                _Form.Dispose();
                _Form = null;
            }

            return 0;
        }

        //********************************************************************************
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        //********************************************************************************
        public void FlushData()
        {
            ;
        }

        //********************************************************************************
        /// <summary>
        /// Returns information about the resource editor
        /// </summary>
        /// <param name="info"></param>
        /// <returns></returns>
        /// <created>UPh,27.06.2011</created>
        /// <changed>UPh,27.06.2011</changed>
        //********************************************************************************
        public int GetInfoData(ref CPAICEInfo info)
        {
            info.SizeMode = enmCustomEditorSizeMode.MaxClient;           
            info.Flags = enmCustomControlFlags.WantSelChange;
            return 0;
        }

        //********************************************************************************
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        //********************************************************************************
        public Size GetSize()
        {
            // set size of form to size of res-editor window
            return new Size(0,0);
        }

        //********************************************************************************
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        //********************************************************************************
        public void OnClose()
        {
            
        }

        //********************************************************************************
        /// <summary>
        /// 
        /// </summary>
        /// <param name="inx"></param>
        /// <param name="display"></param>
        /// <returns></returns>
        //********************************************************************************
        public int OnFilterToken(int inx, ref bool display)
        {
            return 0;
        }

        //********************************************************************************
        /// <summary>
        /// Creates an URI from an URL string
        /// </summary>
        /// <param name="str">the string</param>
        /// <returns></returns>
        /// <created>UPh,27.06.2011</created>
        /// <changed>UPh,27.06.2011</changed>
        //********************************************************************************
        private Uri GetUri(string str)
        {
            // Full http(s) url
            if (str.StartsWith("http:", StringComparison.CurrentCultureIgnoreCase) ||
                str.StartsWith("https:", StringComparison.CurrentCultureIgnoreCase))
            {
                return new Uri(str);
            }

            // Precede with http, if it starts with www
            if (str.StartsWith("www.", StringComparison.CurrentCultureIgnoreCase))
            {
                return new Uri("http://" + str);
            }

            // Find local file
            if (File.Exists(str))
            {
                return new Uri(str);
            }

            // Find relative to project folder
            CPAIProject project = AddInComponent.StaticApplicationTools.GetCurProject();
            if (project != null)
            {
                string path = project.GetProperty(ProjectProperties.Folder).ToString();
                string path2 = Path.Combine(path, str);
                if (File.Exists(path2))
                {
                    return new Uri(path2);
                }

            }


            return null;
        }

        //********************************************************************************
        /// <summary>
        /// String selection has changed
        /// </summary>
        /// <param name="tokensel"></param>
        /// <param name="redraw"></param>
        /// <returns></returns>
        //********************************************************************************
        public int OnSelChange(CPAITokenSelection tokensel, ref bool redraw)
        {
            // We support only single selection
            if (tokensel.GetCount() != 1)
            {
                _Form.webBrowser.Document.OpenNew(true);
                return 0;
            }

            int index = 0;
            CPAIToken token = tokensel.GetToken(0, ref index, false);

            string url = token.GetProperty("U:ContextImage") as string;


            if (string.IsNullOrEmpty(url))
            {
                // If string has no context image, try resource
                url = token.GetResource().GetProperty("U:ContextImage") as string;
            }

            if (string.IsNullOrEmpty(url))
            {
                _Form.webBrowser.Document.OpenNew(true);
                _Form.webBrowser.Document.Write(DnContextViewer.Properties.Resources.strNoURLEntered);
                return 0;

            }

            try
            {
                Uri uri = GetUri(url);
                if (uri == null)
                {
                    _Form.webBrowser.Document.OpenNew(true);
                    _Form.webBrowser.Document.Write(string.Format(Properties.Resources.strCannotParseURL, url));
                    return 0;
                }
                _Form.webBrowser.Navigate(uri);
            }
            catch (Exception e)
            {
                _Form.webBrowser.Document.OpenNew(true);
                _Form.webBrowser.Document.Write(e.Message);
            }

            return 0;
        }

        //********************************************************************************
        /// <summary>
        /// 
        /// </summary>
        /// <param name="size"></param>
        /// <returns></returns>
        //********************************************************************************
        public int OnSize(System.Drawing.Size size)
        {
            _Form.ClientSize = size;
            if (!_Form.Visible)
                _Form.Show();
            return 0;

        }

        //********************************************************************************
        /// <summary>
        /// 
        /// </summary>
        /// <param name="toksel"></param>
        /// <param name="text"></param>
        /// <returns></returns>
        //********************************************************************************
        public int OnTextInput(CPAITokenSelection toksel, string text)
        {
            return 0;
        }

        //********************************************************************************
        /// <summary>
        /// 
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="lparam"></param>
        /// <param name="wparam"></param>
        /// <param name="cancel"></param>
        /// <returns></returns>
        //********************************************************************************
        public int OnWindowMessage(int msg, IntPtr lparam, IntPtr wparam, ref bool cancel)
        {
            return 0;
        }

        //********************************************************************************
        /// <summary>
        /// 
        /// </summary>
        /// <param name="hdc"></param>
        /// <returns></returns>
        //********************************************************************************
        public int Paint(int hdc)
        {
            return 0;
        }

        //********************************************************************************
        /// <summary>
        /// 
        /// </summary>
        /// <param name="inx"></param>
        /// <param name="flags"></param>
        /// <returns></returns>
        //********************************************************************************
        public int UpdateCtrl(int inx, UpdateCtrlFlags flags)
        {
            return 0;
        }
    }
}
