﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Pass.AddIn.Core;
using Pass.AddIn.Framework;
using System.Windows.Forms;

namespace DnContextViewer
{
    class ToolsComponent : Tools
    {
        //********************************************************************************
        /// <summary>
        /// Returns information about every tool that this add-in provides
        /// </summary>
        /// <param name="nIndex">Index, of the tool</param>
        /// <param name="toolInfo">Object that is filled with tool information</param>
        /// <returns></returns>
        //********************************************************************************
        public override uint GetToolInfo(int nIndex, ref CPAIToolInfo toolInfo)
        {
            switch (nIndex)
            {
                case 0:
                    // ResourceDisplay is returned as "virtual tool"
                    toolInfo.Type = ToolTypes.ResourceDisplay;
                    break;

                case 1:
                    toolInfo.Type = ToolTypes.Menu;
                    toolInfo.MenuName = Properties.Resources.strMenuEntry;
                    break;

                default:
                    return 1; // stops asking for additional tools
            }
            return 0; 
        }

        //********************************************************************************
        /// <summary>
        /// Called to execute a tool
        /// </summary>
        /// <param name="nIndex"></param>
        /// <param name="apptools"></param>
        /// <returns></returns>
        //********************************************************************************
        public override uint ExecuteTool(int nIndex, CPAIApplicationTools apptools)
        {
            if (nIndex == 1)
            {
                // "Prepare project for context display"
                CPAIProject project = apptools.GetCurProject();
                if (project == null)
                    return 0;

                using (FormPrepare form = new FormPrepare())
                {
                    if (form.ShowDialog() != DialogResult.OK)
                        return 0;
                }


                // There are no enumerations for the PDF_USEIN_ constants yet.
                // use values from addin.h

                project.DefineUserProperty("U:ContextImage",
                    Properties.Resources.strContextImage, 
                    0x00010000 /* PDF_USEIN_RESOURCE */ |
                    0x00020000 /* PDF_USEIN_SRCSTRING */ |
                    0x00040000 /* PDF_USEIN_TRNSTRING */, 
                    (int) PropertyTypeDefinitions.String,
                    0, null);

            }

            return 0;
        }


    }
}
