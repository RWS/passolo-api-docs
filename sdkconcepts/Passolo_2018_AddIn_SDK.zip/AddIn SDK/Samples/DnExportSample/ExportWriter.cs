﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Pass.AddIn.Core;

namespace DnExportSample
{
    class ExportWriter : IPAINetExportWriter
    {
        StreamWriter _File = null;

        public int Open(string filename)
        {
            _File = new StreamWriter(filename);
            return 0; 
        }

        public int Write(string filename, CPAIStringList stringlist, CPAIExportOptions expoptions)
        {
            if (_File == null)
                return 1;  

            CPAIListInfo listinfo = stringlist.GetListInfo();

            int count = stringlist.GetTokenCount();

            for (int i = 0; i < count; i++)
            {
                if (!expoptions.TokenInFilter(i))
                    continue;

                CPAIToken token = stringlist.GetToken(i, false);
                if (token == null)
                    continue;

                // Write string list id and string number 
                int number = (int) token.GetProperty(enmTokenProperties.Number);
                int extnumber = (int) token.GetProperty(enmTokenProperties.Extnumber);

                string line = string.Format("@{0}-{1}-{2}---------------",
                    listinfo.ID,
                    number,
                    extnumber);
                _File.WriteLine(line);
                    
                // Write the text
                string text = token.GetText();
                text = text.Replace("\n", "\r\n");
                _File.WriteLine(text);
            }

            return 0;


        }

        public int Close(string filename)
        {
            _File.Close();
            _File = null;
            return 0;
        }

        public int Destroy()
        {
            return 0;
        }
    }
}
