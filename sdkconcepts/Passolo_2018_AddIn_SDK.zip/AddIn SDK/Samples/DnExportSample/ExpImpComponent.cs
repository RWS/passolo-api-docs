﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Pass.AddIn.Framework;
using Pass.AddIn.Core;

namespace DnExportSample
{
    //--------------------------------------------------------------------------------
    /// <summary>
    /// 
    /// </summary>
    //--------------------------------------------------------------------------------
    class ExpImpComponent : ExportImport
    {
        //********************************************************************************
        /// <summary>
        /// Define some info about the export functionality of this add-in
        /// </summary>
        /// <param name="eximpdata"></param>
        /// <returns></returns>
        //********************************************************************************
        public override int GetExpImpData(CExpImpData eximpdata)
        {
            eximpdata.Extension = "exptest";
            eximpdata.MultiFileMode = enmMultiFileMode.CanCollect;
            return 0;
        }

        //********************************************************************************
        /// <summary>
        /// Creates the ExportWriter object and returns it to Passolo
        /// </summary>
        /// <returns></returns>
        //********************************************************************************
        public override IPAINetExportWriter GetExportWriter()
        {
            ExportWriter writer = new ExportWriter();

            return writer; 
        }

        //********************************************************************************
        /// <summary>
        /// Called by Passolo to import a file
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="import"></param>
        /// <returns></returns>
        //********************************************************************************
        public override int Import(string filename, CPAIImport import)
        {
            ImportReader reader = new ImportReader(filename, import);
            reader.Import();
            return 0;
        }

    }
}
