﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Pass.AddIn.Core;
using System.IO;

namespace DnSimpleParser
{
    class TBFFileParser
    {
        private string _SourceFile;
        private enmParsingTypes _Action;
        private CPAICustomFile _CustomFile;

        // used when generating target file
        private bool IsGeneratingTarget {get{return _Action == enmParsingTypes.GenerateTarget;}}
        private string _TargetFile;

        // Definitions of the file type we're supporting
        static public string FileTypeExtension   {get {return "tbf";}}
        static public string FileTypeName        {get {return "TBD File Parser";}}
        static public string FileTypeDescription {get {return "Tab Separated Bi-Lingual File Parser";}}


        //********************************************************************************
        /// <summary>
        /// 
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="action"></param>
        /// <param name="customFile"></param>
        /// <returns></returns>
        /// <created>UPh,29.03.2011</created>
        /// <changed>UPh,29.03.2011</changed>
        //********************************************************************************
        public TBFFileParser(string filename, enmParsingTypes action, CPAICustomFile customFile)
        {
            _SourceFile = filename;
            _Action     = action;
            _CustomFile = customFile;

            if (IsGeneratingTarget)
                _TargetFile = customFile.GetTargetFile();
        }


        //********************************************************************************
        /// <summary>
        /// 
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="action"></param>
        /// <param name="customFile"></param>
        /// <returns></returns>
        /// <created>UPh,29.03.2011</created>
        /// <changed>UPh,29.03.2011</changed>
        //********************************************************************************
        public bool ParseFile()
        {
            // Define the columns in the tab-delimited file
            int idcol = 0;        // This column contains the string id
            int sourcecol = 1;    // This is the source text column
            int targetcol = 2;    // This is the target text column

            // Create Resource
            CPAIResource res = _CustomFile.HandleResource("TBF Stringlist", "Strings", 0, 0);
            // If we're just listing the content we're done
            if (_Action == enmParsingTypes.ListContent)
                return true;

            // Open the file for reading
            StreamReader reader = File.OpenText(_SourceFile);
            if (reader == null)
                return false;

            // When generating the target file we write to a temporary file
            string tempTargetFile = "";
            StreamWriter writer = null;
            if (IsGeneratingTarget)
            {
                tempTargetFile = Path.GetTempFileName();
                writer = new StreamWriter(tempTargetFile);
            }

            // When aligning we're reading the target file
            if (_Action == enmParsingTypes.ScanTarget)
                sourcecol = targetcol;

            while (!reader.EndOfStream)
            {
                // Read the line and split to parts
                string line = reader.ReadLine();
                String [] parts = line.Split('\t');
                bool bValidLine = false; // is this a line with localizable text?
                if (idcol < parts.Length &&
                    sourcecol < parts.Length &&
                    targetcol < parts.Length)
                    bValidLine = true;

                // Push data to Passolo
                if (bValidLine)
                {
                    CPAIToken tok = res.GetToken(0, true);
                    tok.SetProperty(enmTokenProperties.ID, parts[idcol]);
                    tok.SetProperty(enmTokenProperties.Text, parts[sourcecol]);
                    res.HandleToken();

                    // When generating target read translation back and build line again
                    if (IsGeneratingTarget)
                    {
                        parts[targetcol] = (String) tok.GetProperty(enmTokenProperties.Text, PropSelectionType.Default);
                        line = string.Join("\t", parts);
                    }
                }

                if (IsGeneratingTarget)
                {
                    writer.WriteLine(line);
                }

            }

            reader.Close();

            // Writing target
            if (IsGeneratingTarget)
            {
                writer.Close();
                if (File.Exists(_TargetFile))
                    File.Delete(_TargetFile);

                File.Move(tempTargetFile, _TargetFile);
            }

            return true;
        }
    }
}
