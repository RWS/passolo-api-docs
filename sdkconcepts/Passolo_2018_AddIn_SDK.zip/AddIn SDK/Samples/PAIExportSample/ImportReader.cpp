#include "StdAfx.h"
#include "ImportReader.h"

//********************************************************************************
/// <summary>
/// Constructor
/// </summary>
/// <param name="filename">The file to import</param>
/// <param name="callback">Callback functions to Passolo</param>
/// <returns></returns>
//********************************************************************************
CImportReader::CImportReader(LPCWSTR filename, IPAIImport *callback)
{
    m_strFileName = filename;;
    m_pCallback = callback;

    m_nCurrentListID = 0;
    m_nCurrentNumber = 0;
    m_nCurrentExtNumber = 0;
}


//********************************************************************************
/// <summary>
/// Destructor
/// </summary>
/// <returns></returns>
/// <created>UPh,30.03.2011</created>
/// <changed>UPh,30.03.2011</changed>
//********************************************************************************
CImportReader::~CImportReader()
{

}

//********************************************************************************
/// <summary>
/// Starts the import
/// </summary>
/// <returns></returns>
//********************************************************************************
BOOL CImportReader::Import()
{
    CStdioFile file;
    if (!file.Open(m_strFileName, CFile::modeRead))
        return FALSE;

    CString line;

    for(;;)
    {
        if (!file.ReadString(line))
        {
            HandleCurrentText();
            break;
        }

        if (lstrlen(line) > 0 && line[0] == '@')
        {
            // Send current text to Passolo
            HandleCurrentText();

            // Handle the new id 
            HandleIDLine(line);
            continue;
        }

        // Append line to current string
        AppendLineToCurrentText(line);
    }

    file.Close();

    return TRUE;

}

//********************************************************************************
/// <summary>
/// Resets the current text and the current string number
/// </summary>
/// <returns></returns>
//********************************************************************************
void CImportReader::ResetCurrentText()
{
    m_nCurrentNumber = 0;
    m_nCurrentExtNumber = 0;
    m_strCurrentText.Empty();

}

//********************************************************************************
/// <summary>
/// Appends a line to the current text
/// </summary>
/// <param name="line"></param>
/// <returns></returns>
//********************************************************************************
void CImportReader::AppendLineToCurrentText(LPCTSTR line)
{
    if (!m_strCurrentText.IsEmpty())
        m_strCurrentText += _T("\n");
    m_strCurrentText += line;
}

                                        
//********************************************************************************
/// <summary>
/// Reads the line of format "@[ListID]-[StringNumber]-[StringExtNumber]"
/// </summary>
/// <param name="line"></param>
/// <returns></returns>
//********************************************************************************
BOOL CImportReader::HandleIDLine(LPCTSTR line)
{
    if (lstrlen(line) < 3 || line[0] != '@')
        return FALSE;
        
    DWORD listid = _tcstoul_l(line + 1, NULL, 10, NULL);

    if (m_nCurrentListID != listid)
    {
        // Switch to another string list
        m_nCurrentListID = listid;
        m_pCallback->ImpDefineID(m_nCurrentListID);
    }

    ResetCurrentText();

    // Read string number
    LPCTSTR p = _tcschr(line, '-');
    if (p == NULL)
        return FALSE;

    int number = _ttoi(p + 1);

    // Read string extended number
    p = _tcschr(p + 1, '-');
    if (p == NULL)
        return FALSE;
    int extnumber = _ttoi(p + 1);

    m_nCurrentNumber = number;
    m_nCurrentExtNumber = extnumber;

    return TRUE;
}

//********************************************************************************
/// <summary>
/// Sends the current text to Passolo 
/// </summary>
/// <returns></returns>
//********************************************************************************
void CImportReader::HandleCurrentText()
{
    if (m_nCurrentListID == 0 ||
        m_nCurrentNumber == 0 ||
        m_strCurrentText.IsEmpty())
        return;

    BSTR bstrText = ::SysAllocString(m_strCurrentText);
    m_pCallback->ImpTranslate(m_nCurrentNumber, m_nCurrentExtNumber, 0, bstrText);
    ::SysFreeString(bstrText);

    ResetCurrentText();
}
