// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the PAIEXPORTSAMPLE_EXPORTS
// symbol defined on the command line. This symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// PAIEXPORTSAMPLE_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#ifdef ADDIN_EXPORTS
#define ADDIN_API __declspec(dllexport)
#else
#define ADDIN_API __declspec(dllimport)
#endif


#include "..\..\addin.h"


extern "C"
{
    extern ADDIN_API HRESULT PAIFN_LoadAddIn(PAISTRUCT_INTERFACE_VERSION *ver);
    extern ADDIN_API HRESULT PAIFN_Initialize(PAISTRUCT_INIT *init, IPAIApplicationTools *apptools, IPAIAddIn *addin);
    extern ADDIN_API HRESULT PAIFN_GetExpImpData(PAISTRUCT_EXPIMPDATA *expimpdata);
    extern ADDIN_API HRESULT PAIFN_GetExportWriter(IPAIExportWriter **expwriter);
    extern ADDIN_API HRESULT PAIFN_Import(LPCWSTR filename, IPAIImport *callback);
    extern ADDIN_API HRESULT PAIFN_About(HWND hParent, BSTR *text);
}