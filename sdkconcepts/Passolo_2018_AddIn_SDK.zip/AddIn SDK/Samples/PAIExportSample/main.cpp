// PAIExportSample.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "main.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


IPAIApplicationTools *g_pAppTools = NULL;
IPAIAddIn *g_pAddIn = NULL;

// The one and only application object

CWinApp theApp;

using namespace std;

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	HMODULE hModule = ::GetModuleHandle(NULL);

	if (hModule != NULL)
	{
		// initialize MFC and print and error on failure
		if (!AfxWinInit(hModule, NULL, ::GetCommandLine(), 0))
		{
			// TODO: change error code to suit your needs
			_tprintf(_T("Fatal Error: MFC initialization failed\n"));
			nRetCode = 1;
		}
		else
		{
			// TODO: code your application's behavior here.
		}
	}
	else
	{
		// TODO: change error code to suit your needs
		_tprintf(_T("Fatal Error: GetModuleHandle failed\n"));
		nRetCode = 1;
	}

	return nRetCode;
}


//********************************************************************************
/// <summary>
/// Called when the add-in is loaded
/// </summary>
/// <param name="ver"></param>
/// <returns></returns>
//********************************************************************************
ADDIN_API HRESULT PAIFN_LoadAddIn(PAISTRUCT_INTERFACE_VERSION *ver)
{
    // Set current interface version numbers
    PAI_SET_INTERFACE_VERSION(ver);
    return S_OK;
}

//********************************************************************************
/// <summary>
/// 
/// </summary>
/// <param name="init"></param>
/// <param name="apptools"></param>
/// <param name="addin"></param>
/// <returns></returns>
//********************************************************************************
ADDIN_API HRESULT PAIFN_Initialize(PAISTRUCT_INIT *init, IPAIApplicationTools *apptools, IPAIAddIn *addin)
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());
    
    init->Type    = PAITYPE_EXPORT | PAITYPE_IMPORT;
    init->Style   = 0;//PAISTYLE_SETUPDATA;

    TCHAR resfile[MAX_PATH];
    if (apptools->ATFindLanguageFile(NULL, theApp.m_hInstance, resfile, _countof(resfile)) == S_OK)
    {
        HINSTANCE hResource = LoadLibrary(resfile);
        AfxSetResourceHandle(hResource);
    }

    // Name of AddIn
    CString rcname;
    rcname.LoadString(IDS_ADDIN_NAME);

    lstrcpyn(init->Name, rcname, _countof(init->Name));
#ifdef _DEBUG
    lstrcpyn(init->Name, rcname + L" (DEBUG)", _countof(init->Name));
#endif

    // Identifier of AddIn 
    lstrcpyn(init->Ident, L"ExportExample", _countof(init->Ident));

    // Description of AddIn
    CString rcdesc;
    rcdesc.LoadString(IDS_ADDIN_INFOTEXT);
    lstrcpyn(init->InfoText, rcdesc, _countof(init->InfoText));

    g_pAppTools = apptools;
    g_pAddIn = addin;

    return S_OK;
}

//********************************************************************************
/// <summary>
/// returns text for "About Addin..." dialog
/// </summary>
/// <param name="hParent">The parent window, used if we display our own dialog</param>
/// <param name="text">Text for standard dialog</param>
/// <returns></returns>
//********************************************************************************
ADDIN_API HRESULT PAIFN_About(HWND hParent, BSTR *text)
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());

    *text = SysAllocString(_T("(c) SDL Passolo GmbH, Germany"));

    return S_OK;
}