#include "stdafx.h"
#include "main.h"
#include "..\..\addin.h"
#include "ExportWriter.h"
#include "ImportReader.h"


//********************************************************************************
/// <summary>
/// Define some info about the export functionality of this add-in
/// </summary>
/// <param name="expimpdata"></param>
/// <returns></returns>
//********************************************************************************
ADDIN_API HRESULT PAIFN_GetExpImpData(PAISTRUCT_EXPIMPDATA *expimpdata)
{
    // Define Standard-Extension of exported/imported files
    lstrcpyn(expimpdata->Ext,  L"exptest", _countof(expimpdata->Ext));
    expimpdata->MultiFileMode = MFM_CAN_COLLECT;
    return S_OK;                                                                                     
}

//********************************************************************************
/// <summary>
/// Creates the ExportWriter object and returns it to Passolo
/// </summary>
/// <param name="expwriter"></param>
/// <returns></returns>
//********************************************************************************
ADDIN_API HRESULT PAIFN_GetExportWriter(IPAIExportWriter **expwriter)
{
    *expwriter = new CExportWriter;
    return S_OK;
}


//********************************************************************************
/// <summary>
/// Called by Passolo to import a file
/// </summary>
/// <param name="filename"></param>
/// <param name="callback"></param>
/// <returns></returns>
//********************************************************************************
ADDIN_API HRESULT PAIFN_Import(LPCWSTR filename, IPAIImport *callback)
{
    CImportReader importreader(filename, callback);
    importreader.Import();
    return S_OK;
}






