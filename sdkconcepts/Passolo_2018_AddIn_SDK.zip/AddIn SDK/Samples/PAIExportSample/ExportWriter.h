#pragma once
#include "..\..\addin.h"

//--------------------------------------------------------------------------------
/// <summary>
/// 
/// </summary>
//--------------------------------------------------------------------------------
class CExportWriter : public IPAIExportWriter
{
public:
    CExportWriter(void);
    ~CExportWriter(void);

protected:
    CStdioFile m_File; 

    virtual HRESULT EWOpen(LPCWSTR filename);
    virtual HRESULT EWWrite(LPCWSTR filename, IPAIStringList *stringlist, IPAIExportOptions *expopt);
    virtual HRESULT EWClose(LPCWSTR filename);
    virtual HRESULT EWDestroy();
};

